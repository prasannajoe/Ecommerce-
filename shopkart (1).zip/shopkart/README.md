# ShopKart

A full-stack e-commerce website inspired by the overall shopping experience of
marketplaces like Flipkart — original branding, original design, original code.

**Stack:** Node.js + Express (backend/API) · MongoDB + Mongoose (database) · Vanilla HTML/CSS/JS (frontend, no build step)

---

## 1. Project structure

```
shopkart/
├── backend/
│   ├── config/db.js            # MongoDB connection
│   ├── models/                 # Mongoose schemas (see "Database" below)
│   ├── controllers/            # Business logic for each resource
│   ├── routes/                 # Express routers, wired to controllers
│   ├── middleware/              # auth (JWT), adminOnly, error handler
│   ├── seed/seed.js            # Sample categories, products, admin + demo user
│   ├── uploads/                 # Uploaded product images land here
│   ├── server.js                # App entry point
│   ├── package.json
│   └── .env.example             # Copy to .env and fill in
│
└── frontend/
    ├── index.html                # Home page
    ├── products.html             # Product listing (filters, sort, pagination)
    ├── product.html               # Product details page
    ├── cart.html                  # Shopping cart
    ├── checkout.html              # Checkout (address, payment, place order)
    ├── order-confirmation.html    # Order success + tracking
    ├── login.html / register.html
    ├── account.html               # Profile, orders, tracking, wishlist, addresses
    ├── wishlist.html
    ├── admin/                     # Admin dashboard (separate mini-app)
    │   ├── login.html
    │   ├── dashboard.html
    │   ├── products.html
    │   ├── categories.html
    │   ├── orders.html
    │   └── users.html
    ├── css/style.css               # Shared design system
    ├── css/admin.css               # Admin-only styles
    └── js/                         # One JS file per page/concern (see below)
```

The backend also serves the `frontend/` folder as static files, so the whole
site runs from a single Express server (no separate frontend server needed).

---

## 2. Setup

### Requirements
- Node.js 18+
- MongoDB running locally (or a MongoDB Atlas connection string)

### Steps

```bash
cd shopkart/backend
npm install
cp .env.example .env
# then edit .env and set MONGO_URI / JWT_SECRET if needed
npm run seed        # creates sample categories, products, admin & demo users
npm run dev          # starts the server with nodemon (or `npm start`)
```

Open **http://localhost:5000** — the storefront, and
**http://localhost:5000/admin/login.html** — the admin dashboard.

### Demo accounts (created by the seed script)
| Role     | Email                | Password    |
|----------|-----------------------|-------------|
| Admin    | admin@shopkart.com    | Admin@123   |
| Customer | demo@shopkart.com     | Demo@123    |

You can also just register a new customer account from `register.html`.

---

## 3. Database structure

All models live in `backend/models/`. Summary:

- **User** — name, email, hashed password, phone, role (`user`/`admin`)
- **Category** — name, slug, icon
- **Product** — name, slug, description, category ref, brand, price, mrp
  (discount % is a computed virtual), images, stock, specifications, rating,
  numReviews, isFeatured, isDeal
- **Cart** — one per user; items = [{ product, quantity, savedForLater }]
- **Wishlist** — one per user; products = [productId]
- **Address** — saved delivery addresses per user
- **Order** — orderNumber, user, embedded line items (snapshotted price/name),
  shippingAddress, paymentMethod/Status, price breakdown, orderStatus,
  statusHistory
- **OrderItem** — same line items also written to their own collection, so the
  schema mirrors a typical relational order/order-items design
- **Payment** — one per order (simulated gateway result)
- **Review** — product ref, user ref, rating, comment (one review per user
  per product; recalculates the product's average rating automatically)

---

## 4. API overview (all under `/api`)

| Resource   | Routes |
|------------|--------|
| Auth       | `POST /auth/register`, `POST /auth/login`, `GET /auth/me` |
| Categories | `GET /categories`, `POST/PUT/DELETE /categories/:id` (admin) |
| Products   | `GET /products` (search/filter/sort/paginate), `GET /products/:id`, `POST/PUT/DELETE` (admin) |
| Cart       | `GET/POST /cart`, `PUT/DELETE /cart/:productId`, `PUT /cart/:productId/save-for-later` |
| Wishlist   | `GET /wishlist`, `POST /wishlist/:productId` (toggle) |
| Addresses  | `GET/POST /addresses`, `PUT/DELETE /addresses/:id` |
| Orders     | `POST /orders`, `GET /orders`, `GET /orders/:id`, `GET /orders/admin/all` (admin), `PUT /orders/:id/status` (admin) |
| Reviews    | `GET /reviews/:productId`, `POST /reviews/:productId` |
| Admin      | `GET /admin/stats`, `GET /admin/users`, `DELETE /admin/users/:id` |
| Upload     | `POST /upload` (admin, multipart form field `image`) |

All routes except auth/register/login and public GETs require a
`Authorization: Bearer <token>` header. The frontend's `js/api.js` handles
this automatically once you're logged in (token is kept in `localStorage`).

---

## 5. Frontend JS files (one concern per file)

- `js/api.js` — fetch wrapper + auth/token helpers
- `js/main.js` — shared header/footer, icons, toasts, product-art placeholder graphics
- `js/product-card.js` — shared product card markup + add-to-cart/wishlist actions
- `js/home.js`, `js/products.js`, `js/product.js`, `js/cart.js`, `js/checkout.js`, `js/account.js` — one per customer page
- `js/admin-main.js` — shared admin sidebar/shell
- `js/admin-products.js`, `js/admin-categories.js`, `js/admin-orders.js`, `js/admin-users.js` — one per admin page

No frameworks or build tools — open the HTML files' `<script>` tags to see
exactly what each page loads.

---

## 6. Notes & next steps

- Product photos: the seed data uses a neutral placeholder; the frontend
  automatically generates a coloured original icon per product instead of a
  broken image. Upload real photos from the admin dashboard's product form —
  they're stored in `backend/uploads/` and served at `/uploads/...`.
- Payments (UPI/Card/NetBanking) are simulated for this project — there's no
  real payment gateway wired in. Swapping in Razorpay/Stripe would mean
  adding their SDK in `orderController.js` and the checkout page.
- Delivery pincode checking on the product page is a simple simulated
  estimate, not a real courier API.
- This is a learning/demo-quality codebase: clear, commented, and easy to
  extend, rather than optimized for massive scale.
