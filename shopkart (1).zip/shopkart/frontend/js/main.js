/* ShopKart — shared UI shell: header, footer, toasts, icons, and small helpers
   used across every page. Include this AFTER api.js on every page. */

/* ---------- formatting ---------- */
function formatPrice(n) {
  return '₹' + Number(n || 0).toLocaleString('en-IN');
}
function discountPercent(price, mrp) {
  if (!mrp || mrp <= price) return 0;
  return Math.round(((mrp - price) / mrp) * 100);
}

/* ---------- icons (all original, inline SVG) ---------- */
const ICONS = {
  search: `<svg class="search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>`,
  user: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4.4 3.6-7 8-7s8 2.6 8 7"/></svg>`,
  heart: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 21s-7.5-4.9-10-9.5C.5 7.8 3 4 7 4c2.2 0 3.8 1.2 5 3 1.2-1.8 2.8-3 5-3 4 0 6.5 3.8 5 7.5-2.5 4.6-10 9.5-10 9.5Z"/></svg>`,
  heartFilled: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 21s-7.5-4.9-10-9.5C.5 7.8 3 4 7 4c2.2 0 3.8 1.2 5 3 1.2-1.8 2.8-3 5-3 4 0 6.5 3.8 5 7.5-2.5 4.6-10 9.5-10 9.5Z"/></svg>`,
  cart: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.5 3h2l2.6 12.6a2 2 0 0 0 2 1.6h8.4a2 2 0 0 0 2-1.6L21 7H6"/></svg>`,
  menu: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 7h16M4 12h16M4 17h16"/></svg>`,
  check: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M20 6L9 17l-5-5"/></svg>`,
  star: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.9 6.6 7.1.7-5.4 4.7 1.6 7-6.2-3.7-6.2 3.7 1.6-7L2 9.3l7.1-.7L12 2Z"/></svg>`,
  alert: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 8v5M12 16h.01"/></svg>`,
};
function starsRow(rating) {
  let s = '';
  for (let i = 1; i <= 5; i++) s += `<span style="opacity:${i <= Math.round(rating) ? 1 : 0.28}">${ICONS.star}</span>`;
  return `<span class="stars">${s}</span>`;
}

/* ---------- original inline product art (used when a product has no real photo) ---------- */
const ART_PALETTE = ['#2451C4', '#FF7A1A', '#1A9E63', '#8B5CF6', '#0AA6C2', '#E14545', '#C2410C', '#0E8F72'];
function hashColor(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return ART_PALETTE[h % ART_PALETTE.length];
}
function productArt(product) {
  if (product.images && product.images[0] && product.images[0] !== '/images/placeholder.svg') {
    return `<img src="${product.images[0]}" alt="${product.name}">`;
  }
  const c = hashColor(product.name || product._id || 'x');
  return `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
    <rect x="30" y="30" width="140" height="140" rx="20" fill="${c}" opacity="0.12"/>
    <rect x="55" y="55" width="90" height="90" rx="14" fill="${c}" opacity="0.85"/>
    <circle cx="100" cy="100" r="24" fill="#fff" opacity="0.9"/>
    <path d="M92 100l6 6 12-14" stroke="${c}" stroke-width="4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;
}

const CATEGORY_ICON_PATHS = {
  Mobiles: `<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>`,
  Electronics: `<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>`,
  Fashion: `<path d="M8 3l4 3 4-3 4 4-3 3v10H7V10L4 7l4-4Z"/>`,
  'Home & Kitchen': `<path d="M4 11l8-7 8 7M6 10v10h12V10"/>`,
  'Beauty & Personal Care': `<path d="M12 2c3 3 5 6 5 9a5 5 0 0 1-10 0c0-3 2-6 5-9Z"/>`,
  'Sports & Fitness': `<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a13 13 0 0 1 0 18 13 13 0 0 1 0-18Z"/>`,
  Books: `<path d="M4 4h11a3 3 0 0 1 3 3v13H7a3 3 0 0 1-3-3V4Z"/><path d="M18 20a3 3 0 0 0 3-3V6"/>`,
  'Toys & Baby': `<circle cx="12" cy="8" r="3"/><path d="M6 21c0-4 3-6 6-6s6 2 6 6"/>`,
};
function categoryIconSvg(name) {
  return `<svg viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="1.8">${CATEGORY_ICON_PATHS[name] || CATEGORY_ICON_PATHS.Electronics}</svg>`;
}

/* ---------- toast ---------- */
let toastTimer;
function showToast(msg, type = 'ok') {
  let t = document.getElementById('toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'toast';
    document.body.appendChild(t);
  }
  t.className = type === 'error' ? 'error' : '';
  t.innerHTML = `${type === 'error' ? ICONS.alert : ICONS.check}<span>${msg}</span>`;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2600);
}
function showError(err) {
  showToast(err.message || 'Something went wrong', 'error');
}

/* ---------- header / footer shell ---------- */
let SHOPKART_CATEGORIES = [];

async function loadCategoriesOnce() {
  if (SHOPKART_CATEGORIES.length) return SHOPKART_CATEGORIES;
  try {
    SHOPKART_CATEGORIES = await api.get('/categories');
  } catch (e) {
    SHOPKART_CATEGORIES = [];
  }
  return SHOPKART_CATEGORIES;
}

function headerTemplate() {
  return `
  <div class="topbar">
    <div class="container">
      <span>Free delivery on orders above ₹499</span>
      <span>Need help? 1800-123-4567</span>
    </div>
  </div>
  <header class="mainhead">
    <div class="container">
      <button class="hamburger" id="hamburgerBtn" aria-label="Open menu">${ICONS.menu}</button>
      <a href="index.html" class="logo">
        <svg width="32" height="32" viewBox="0 0 40 40" fill="none">
          <rect width="40" height="40" rx="10" fill="#2451C4"/>
          <path d="M10 15h20l-2 13a3 3 0 0 1-3 2.5H15a3 3 0 0 1-3-2.5L10 15Z" fill="#fff"/>
          <path d="M14 15v-2a6 6 0 0 1 12 0v2" stroke="#FF7A1A" stroke-width="2.4" fill="none"/>
        </svg>
        <span class="logo-text">Shop<span>Kart</span></span>
      </a>
      <div class="searchwrap">
        ${ICONS.search}
        <input id="searchInput" type="text" placeholder="Search for products, brands and more" onkeydown="if(event.key==='Enter')runSearch()">
        <button class="search-go" onclick="runSearch()" aria-label="Search">${ICONS.search.replace('search-icon','')}</button>
      </div>
      <div class="head-actions">
        <button class="head-btn hide-mobile" id="loginHeadBtn">
          ${ICONS.user}
          <span id="loginLabel">Login</span>
        </button>
        <button class="head-btn" onclick="location.href='wishlist.html'">
          ${ICONS.heart}
          <span id="wishBadgeWrap"></span>
          Wishlist
        </button>
        <button class="head-btn" onclick="location.href='cart.html'">
          ${ICONS.cart}
          <span id="cartBadgeWrap"></span>
          Cart
        </button>
      </div>
    </div>
    <div class="mobile-search container">
      <div class="searchwrap">
        ${ICONS.search}
        <input id="searchInputMobile" type="text" placeholder="Search for products..." onkeydown="if(event.key==='Enter')runSearch(true)">
      </div>
    </div>
    <nav class="catnav"><div class="container" id="catNavRow"></div></nav>
  </header>
  <div class="drawer-backdrop" id="drawerBackdrop"></div>
  <div class="drawer" id="drawer"></div>
  `;
}

function footerTemplate() {
  return `
  <div class="container">
    <div class="foot-grid">
      <div>
        <a href="index.html" class="logo" style="margin-bottom:14px;">
          <svg width="30" height="30" viewBox="0 0 40 40" fill="none">
            <rect width="40" height="40" rx="10" fill="#2451C4"/>
            <path d="M10 15h20l-2 13a3 3 0 0 1-3 2.5H15a3 3 0 0 1-3-2.5L10 15Z" fill="#fff"/>
          </svg>
          <span class="logo-text" style="color:#fff;">Shop<span>Kart</span></span>
        </a>
        <p style="max-width:250px;">India's original marketplace for electronics, fashion, home and more — quality products, honest prices.</p>
        <div class="social-row" style="margin-top:14px;">
          <a href="#" aria-label="Instagram"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/></svg></a>
          <a href="#" aria-label="Facebook"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3Z"/></svg></a>
          <a href="#" aria-label="X"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4l16 16M20 4L4 20"/></svg></a>
        </div>
      </div>
      <div>
        <h5>Company</h5>
        <a href="#">About Us</a><a href="#">Contact Us</a><a href="#">Careers</a>
        <a href="admin/login.html">Admin Login</a>
      </div>
      <div>
        <h5>Policies</h5>
        <a href="#">Privacy Policy</a><a href="#">Terms &amp; Conditions</a><a href="#">Shipping Policy</a><a href="#">Return &amp; Refund Policy</a>
      </div>
      <div>
        <h5>Support</h5>
        <a href="#">FAQ</a><a href="#">Customer Support</a><a href="account.html?tab=orders">Track Order</a>
      </div>
      <div>
        <h5>Account</h5>
        <a href="login.html">Login / Sign Up</a>
        <a href="account.html?tab=orders">My Orders</a>
        <a href="wishlist.html">Wishlist</a>
        <a href="cart.html">Cart</a>
      </div>
    </div>
    <div class="foot-bottom">
      <span>© 2026 ShopKart. All rights reserved. Original brand — not affiliated with any other marketplace.</span>
      <span>Made for shoppers across India 🇮🇳</span>
    </div>
  </div>`;
}

async function renderShell(activeCategorySlug) {
  const headerEl = document.getElementById('site-header');
  const footerEl = document.getElementById('site-footer');
  if (headerEl) headerEl.innerHTML = headerTemplate();
  if (footerEl) footerEl.innerHTML = footerTemplate();

  await loadCategoriesOnce();
  const catNav = document.getElementById('catNavRow');
  if (catNav) {
    let html = `<a href="products.html" class="${!activeCategorySlug ? 'active' : ''}">All Products</a>`;
    SHOPKART_CATEGORIES.forEach((c) => {
      html += `<a href="products.html?category=${c._id}" class="${activeCategorySlug === c._id ? 'active' : ''}">${c.name}</a>`;
    });
    html += `<a href="products.html?deal=1" style="color:var(--amber);">Offers</a>`;
    catNav.innerHTML = html;
  }

  wireHeaderEvents();
  await updateHeaderBadges();
}

function wireHeaderEvents() {
  const hamburgerBtn = document.getElementById('hamburgerBtn');
  const drawer = document.getElementById('drawer');
  const backdrop = document.getElementById('drawerBackdrop');
  if (hamburgerBtn) {
    hamburgerBtn.addEventListener('click', () => {
      let html = `<div class="drawer-head"><span class="logo-text">Shop<span style="color:var(--amber)">Kart</span></span><button onclick="closeDrawer()" style="font-size:22px;">&times;</button></div>`;
      html += `<a href="products.html">All Products</a>`;
      SHOPKART_CATEGORIES.forEach((c) => { html += `<a href="products.html?category=${c._id}">${c.name}</a>`; });
      html += `<a href="products.html?deal=1">Offers</a>`;
      html += `<a href="cart.html">Cart</a><a href="wishlist.html">Wishlist</a>`;
      if (isLoggedIn()) {
        html += `<a href="account.html">My Account</a><a href="#" onclick="logout();return false;">Logout</a>`;
      } else {
        html += `<a href="login.html">Login / Sign Up</a>`;
      }
      html += `<a href="admin/login.html">Admin Dashboard</a>`;
      drawer.innerHTML = html;
      drawer.classList.add('open');
      backdrop.classList.add('open');
    });
    backdrop.addEventListener('click', closeDrawer);
  }
  const loginBtn = document.getElementById('loginHeadBtn');
  if (loginBtn) {
    loginBtn.addEventListener('click', () => {
      if (isLoggedIn()) location.href = 'account.html';
      else location.href = 'login.html';
    });
  }
}
function closeDrawer() {
  document.getElementById('drawer').classList.remove('open');
  document.getElementById('drawerBackdrop').classList.remove('open');
}

async function updateHeaderBadges() {
  const loginLabel = document.getElementById('loginLabel');
  if (loginLabel) loginLabel.textContent = isLoggedIn() ? (getUser()?.name?.split(' ')[0] || 'Account') : 'Login';

  const cartWrap = document.getElementById('cartBadgeWrap');
  const wishWrap = document.getElementById('wishBadgeWrap');
  if (!isLoggedIn()) {
    if (cartWrap) cartWrap.innerHTML = '';
    if (wishWrap) wishWrap.innerHTML = '';
    return;
  }
  try {
    const [cart, wishlist] = await Promise.all([api.get('/cart'), api.get('/wishlist')]);
    const cartCount = (cart.items || []).filter(i => !i.savedForLater).reduce((a, i) => a + i.quantity, 0);
    const wishCount = (wishlist.products || []).length;
    if (cartWrap) cartWrap.innerHTML = cartCount > 0 ? `<span class="badge">${cartCount}</span>` : '';
    if (wishWrap) wishWrap.innerHTML = wishCount > 0 ? `<span class="badge">${wishCount}</span>` : '';
  } catch (e) { /* ignore badge errors */ }
}

function runSearch(mobile = false) {
  const val = document.getElementById(mobile ? 'searchInputMobile' : 'searchInput').value.trim();
  location.href = 'products.html?search=' + encodeURIComponent(val);
}

function logout() {
  clearAuth();
  showToast('Logged out successfully');
  setTimeout(() => location.href = 'index.html', 500);
}

function requireLogin(redirectAfter) {
  if (!isLoggedIn()) {
    location.href = 'login.html' + (redirectAfter ? '?next=' + encodeURIComponent(redirectAfter) : '');
    return false;
  }
  return true;
}

function qs(name) {
  return new URLSearchParams(location.search).get(name);
}
