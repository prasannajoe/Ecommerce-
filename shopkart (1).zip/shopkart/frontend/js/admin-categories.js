/* Admin: manage categories */
let adminCatsCache = [];

(async function initAdminCategories() {
  if (!adminGuard()) return;
  renderAdminShell('categories');
  await loadAdminCategories();
})();

async function loadAdminCategories() {
  const main = document.getElementById('adminMain');
  main.innerHTML = '<div class="loading-center"><div class="spinner"></div></div>';
  try {
    adminCatsCache = await api.get('/categories');
    renderAdminCategories();
  } catch (e) {
    main.innerHTML = '<div class="empty-state">Could not load categories.</div>';
  }
}

function renderAdminCategories() {
  const main = document.getElementById('adminMain');
  main.innerHTML = `
    <div class="admin-topbar"><h1>Manage Categories</h1></div>
    <div class="admin-panel">
      <h3>Add New Category</h3>
      <div style="display:flex;gap:10px;">
        <input id="newCatName" type="text" placeholder="e.g. Pet Supplies" style="flex:1;border:1.5px solid var(--line);border-radius:9px;padding:10px 13px;font-size:13.5px;">
        <button class="btn btn-primary btn-sm" onclick="addAdminCategory()">Add Category</button>
      </div>
    </div>
    <div class="admin-panel" style="padding:0;">
      <div class="table-wrap"><table class="admin-table">
        <thead><tr><th>Category</th><th>Slug</th><th>Actions</th></tr></thead>
        <tbody>
          ${adminCatsCache.map(c => `<tr>
            <td style="display:flex;align-items:center;gap:10px;"><div class="cat-icon" style="width:32px;height:32px;">${categoryIconSvg(c.name)}</div>${c.name}</td>
            <td>${c.slug}</td>
            <td><button class="icon-btn danger" title="Delete" onclick="deleteAdminCategory('${c._id}')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m2 0v14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V6h12Z"/></svg></button></td>
          </tr>`).join('') || '<tr><td colspan="3" style="color:var(--ink-soft);">No categories yet.</td></tr>'}
        </tbody>
      </table></div>
    </div>`;
}

async function addAdminCategory() {
  const name = document.getElementById('newCatName').value.trim();
  if (!name) { showToast('Please enter a category name', 'error'); return; }
  try {
    await api.post('/categories', { name });
    showToast('Category added');
    document.getElementById('newCatName').value = '';
    await loadAdminCategories();
  } catch (e) { showError(e); }
}
async function deleteAdminCategory(id) {
  if (!confirm('Delete this category?')) return;
  try {
    await api.del('/categories/' + id);
    showToast('Category deleted');
    await loadAdminCategories();
  } catch (e) { showError(e); }
}
