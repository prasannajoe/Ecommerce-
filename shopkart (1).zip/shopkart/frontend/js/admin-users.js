/* Admin: view and manage customer accounts */
let adminUsersCache = [];

(async function initAdminUsers() {
  if (!adminGuard()) return;
  renderAdminShell('users');
  await loadAdminUsers();
})();

async function loadAdminUsers() {
  const main = document.getElementById('adminMain');
  main.innerHTML = '<div class="loading-center"><div class="spinner"></div></div>';
  try {
    adminUsersCache = await api.get('/admin/users');
    renderAdminUsers();
  } catch (e) {
    main.innerHTML = '<div class="empty-state">Could not load customers.</div>';
  }
}

function renderAdminUsers() {
  const main = document.getElementById('adminMain');
  main.innerHTML = `
    <div class="admin-topbar"><h1>Manage Customers</h1><span style="font-size:12.5px;color:var(--ink-soft);">${adminUsersCache.length} registered customers</span></div>
    <div class="admin-panel" style="padding:0;">
      <div class="table-wrap"><table class="admin-table">
        <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Joined</th><th>Actions</th></tr></thead>
        <tbody>
          ${adminUsersCache.map(u => `<tr>
            <td>${u.name}</td><td>${u.email}</td><td>${u.phone || '—'}</td>
            <td>${new Date(u.createdAt).toLocaleDateString('en-IN')}</td>
            <td><button class="icon-btn danger" title="Delete customer" onclick="deleteAdminUser('${u._id}')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m2 0v14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V6h12Z"/></svg></button></td>
          </tr>`).join('') || '<tr><td colspan="5" style="color:var(--ink-soft);">No customers yet.</td></tr>'}
        </tbody>
      </table></div>
    </div>`;
}

async function deleteAdminUser(id) {
  if (!confirm('Delete this customer account? This cannot be undone.')) return;
  try {
    await api.del('/admin/users/' + id);
    showToast('Customer deleted');
    await loadAdminUsers();
  } catch (e) { showError(e); }
}
