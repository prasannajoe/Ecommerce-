/* Shared product card renderer + cart/wishlist actions used on
   home, product listing, wishlist and product-detail "related products". */

let WISHLIST_IDS = [];
async function refreshWishlistIds() {
  if (!isLoggedIn()) { WISHLIST_IDS = []; return; }
  try {
    const wl = await api.get('/wishlist');
    WISHLIST_IDS = (wl.products || []).map(p => p._id);
  } catch (e) { WISHLIST_IDS = []; }
}

function productCardHtml(p) {
  const off = discountPercent(p.price, p.mrp);
  const wished = WISHLIST_IDS.includes(p._id);
  return `
  <div class="pcard">
    <div class="pcard-media" onclick="location.href='product.html?id=${p._id}'">
      ${off > 0 ? `<span class="discount-chip">${off}% OFF</span>` : ''}
      <button class="wish-btn ${wished ? 'active' : ''}" onclick="event.stopPropagation();handleWishlistToggle('${p._id}', this)" aria-label="Toggle wishlist">${wished ? ICONS.heartFilled : ICONS.heart}</button>
      ${productArt(p)}
    </div>
    <div class="pcard-body">
      <span class="brand">${p.brand}</span>
      <h4 onclick="location.href='product.html?id=${p._id}'">${p.name}</h4>
      <div class="rating-row"><span class="rating-pill">${p.rating || '—'}${ICONS.star}</span><span class="count">(${(p.numReviews || 0).toLocaleString('en-IN')})</span></div>
      <div class="price-row">
        <span class="price-now">${formatPrice(p.price)}</span>
        ${p.mrp > p.price ? `<span class="price-was">${formatPrice(p.mrp)}</span><span class="price-off">${off}% off</span>` : ''}
      </div>
      <div class="pcard-ctas">
        <button class="btn btn-outline" onclick="handleAddToCart('${p._id}', this)">Add to Cart</button>
        <button class="btn btn-primary" onclick="handleBuyNow('${p._id}')">Buy Now</button>
      </div>
    </div>
  </div>`;
}

async function handleAddToCart(productId, btnEl) {
  if (!requireLogin(location.pathname.split('/').pop())) return;
  try {
    if (btnEl) { btnEl.disabled = true; }
    await api.post('/cart', { productId, quantity: 1 });
    showToast('Added to cart');
    await updateHeaderBadges();
  } catch (e) {
    showError(e);
  } finally {
    if (btnEl) btnEl.disabled = false;
  }
}

async function handleBuyNow(productId) {
  if (!requireLogin(location.pathname.split('/').pop())) return;
  try {
    await api.post('/cart', { productId, quantity: 1 });
    location.href = 'checkout.html';
  } catch (e) {
    showError(e);
  }
}

async function handleWishlistToggle(productId, btnEl) {
  if (!requireLogin(location.pathname.split('/').pop())) return;
  try {
    await api.post('/wishlist/' + productId);
    await refreshWishlistIds();
    if (btnEl) {
      const nowActive = WISHLIST_IDS.includes(productId);
      btnEl.classList.toggle('active', nowActive);
      btnEl.innerHTML = nowActive ? ICONS.heartFilled : ICONS.heart;
    }
    showToast(WISHLIST_IDS.includes(productId) ? 'Added to wishlist' : 'Removed from wishlist');
    await updateHeaderBadges();
  } catch (e) {
    showError(e);
  }
}
