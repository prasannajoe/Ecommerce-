/* Logic for index.html */
(async function initHome() {
  await renderShell();
  await refreshWishlistIds();

  // Categories
  const catEl = document.getElementById('homeCategories');
  const cats = await loadCategoriesOnce();
  catEl.innerHTML = cats.map(c => `
    <a href="products.html?category=${c._id}" class="cat-card">
      <div class="cat-icon">${categoryIconSvg(c.name)}</div>
      <div><h3>${c.name}</h3><span>Shop now</span></div>
    </a>`).join('');

  // Trending (isFeatured)
  try {
    const trending = await api.get('/products?featured=1&limit=8');
    document.getElementById('trendingGrid').innerHTML = trending.products.length
      ? trending.products.map(productCardHtml).join('')
      : '<div class="empty-state">No trending products yet.</div>';
  } catch (e) {
    document.getElementById('trendingGrid').innerHTML = '<div class="empty-state">Could not load trending products.</div>';
  }

  // Best deals (isDeal)
  try {
    const deals = await api.get('/products?deal=1&limit=8');
    document.getElementById('dealsGrid').innerHTML = deals.products.length
      ? deals.products.map(productCardHtml).join('')
      : '<div class="empty-state">No deals available right now.</div>';
  } catch (e) {
    document.getElementById('dealsGrid').innerHTML = '<div class="empty-state">Could not load deals.</div>';
  }

  // Recommended (just a general page of products, sorted by rating)
  try {
    const rec = await api.get('/products?sort=rating&limit=8');
    document.getElementById('recommendedGrid').innerHTML = rec.products.length
      ? rec.products.map(productCardHtml).join('')
      : '<div class="empty-state">No products available yet. Have you run the seed script?</div>';
  } catch (e) {
    document.getElementById('recommendedGrid').innerHTML = '<div class="empty-state">Could not load products. Is the backend running?</div>';
  }
})();
