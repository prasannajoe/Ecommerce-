/* ShopKart — tiny fetch wrapper used by every page.
   Since the backend serves the frontend too, relative "/api" URLs work
   both in local dev (same Express server) and once deployed. */
const API_BASE = '/api';

function getToken() {
  return localStorage.getItem('shopkart_token');
}
function setAuth(token, user) {
  localStorage.setItem('shopkart_token', token);
  localStorage.setItem('shopkart_user', JSON.stringify(user));
}
function getUser() {
  try { return JSON.parse(localStorage.getItem('shopkart_user')); } catch { return null; }
}
function clearAuth() {
  localStorage.removeItem('shopkart_token');
  localStorage.removeItem('shopkart_user');
}
function isLoggedIn() {
  return !!getToken();
}
function isAdmin() {
  const u = getUser();
  return !!u && u.role === 'admin';
}

/**
 * Core request helper. Throws an Error with a readable message on failure,
 * so callers can just try/catch and show it in a toast.
 */
async function apiRequest(path, { method = 'GET', body, auth = true } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (auth && getToken()) headers['Authorization'] = `Bearer ${getToken()}`;

  let res;
  try {
    res = await fetch(API_BASE + path, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch (networkErr) {
    throw new Error('Could not reach the ShopKart server. Please check your connection.');
  }

  let data = {};
  try { data = await res.json(); } catch { /* empty body is fine */ }

  if (!res.ok) {
    if (res.status === 401) {
      // Token expired or invalid — log the user out locally.
      clearAuth();
    }
    throw new Error(data.message || `Request failed (${res.status})`);
  }
  return data;
}

const api = {
  get: (path) => apiRequest(path, { method: 'GET' }),
  post: (path, body) => apiRequest(path, { method: 'POST', body }),
  put: (path, body) => apiRequest(path, { method: 'PUT', body }),
  del: (path) => apiRequest(path, { method: 'DELETE' }),
};
