/* Logic for products.html — filters, sorting, pagination */
const plpState = {
  search: qs('search') || '',
  category: qs('category') || '',
  brand: [],
  minRating: 0,
  minDiscount: 0,
  maxPrice: 35000,
  sort: 'relevance',
  page: 1,
  limit: 12,
  deal: qs('deal') ? true : false,
};

(async function initProducts() {
  await renderShell(plpState.category);
  await refreshWishlistIds();
  buildStaticFilters();
  await buildCategoryFilter();
  document.getElementById('sortSelect').addEventListener('change', (e) => { plpState.sort = e.target.value; plpState.page = 1; loadProducts(); });
  document.getElementById('priceRange').addEventListener('input', (e) => {
    plpState.maxPrice = Number(e.target.value);
    document.getElementById('priceRangeLabel').textContent = formatPrice(plpState.maxPrice);
  });
  document.getElementById('priceRange').addEventListener('change', () => { plpState.page = 1; loadProducts(); });
  await loadProducts();
})();

function buildStaticFilters() {
  const ratingEl = document.getElementById('filterRating');
  ratingEl.innerHTML = [0, 3, 4, 4.5].map(r => `
    <label class="filter-opt">
      <input type="radio" name="ratingF" ${r === 0 ? 'checked' : ''} onchange="plpState.minRating=${r};plpState.page=1;loadProducts();">
      ${r === 0 ? 'All ratings' : r + '★ &amp; above'}
    </label>`).join('');

  const discountEl = document.getElementById('filterDiscount');
  discountEl.innerHTML = [0, 10, 20, 30].map(d => `
    <label class="filter-opt">
      <input type="radio" name="discountF" ${d === 0 ? 'checked' : ''} onchange="plpState.minDiscount=${d};plpState.page=1;loadProducts();">
      ${d === 0 ? 'All discounts' : d + '% or more'}
    </label>`).join('');
}

async function buildCategoryFilter() {
  const cats = await loadCategoriesOnce();
  const el = document.getElementById('filterCategory');
  el.innerHTML = cats.map(c => `
    <label class="filter-opt">
      <input type="radio" name="categoryF" value="${c._id}" ${plpState.category === c._id ? 'checked' : ''} onchange="setCategoryFilter('${c._id}')">
      ${c.name}
    </label>`).join('') + `
    <label class="filter-opt">
      <input type="radio" name="categoryF" value="" ${!plpState.category ? 'checked' : ''} onchange="setCategoryFilter('')">
      All categories
    </label>`;
}
function setCategoryFilter(id) {
  plpState.category = id;
  plpState.brand = [];
  plpState.page = 1;
  loadProducts();
}

function buildBrandFilter(brands) {
  const el = document.getElementById('filterBrand');
  if (!brands.length) { el.innerHTML = '<span style="font-size:12.5px;color:var(--ink-soft);">No brands found</span>'; return; }
  el.innerHTML = brands.map(b => `
    <label class="filter-opt">
      <input type="checkbox" value="${b}" ${plpState.brand.includes(b) ? 'checked' : ''} onchange="toggleBrandFilter('${b.replace(/'/g, "\\'")}')">
      ${b}
    </label>`).join('');
}
function toggleBrandFilter(brand) {
  if (plpState.brand.includes(brand)) plpState.brand = plpState.brand.filter(b => b !== brand);
  else plpState.brand.push(brand);
  plpState.page = 1;
  loadProducts();
}

function resetFilters() {
  plpState.brand = []; plpState.minRating = 0; plpState.minDiscount = 0; plpState.maxPrice = 35000;
  plpState.category = ''; plpState.search = ''; plpState.deal = false; plpState.page = 1;
  document.getElementById('priceRange').value = 35000;
  document.getElementById('priceRangeLabel').textContent = '₹35,000';
  buildCategoryFilter();
  buildStaticFilters();
  loadProducts();
}

async function loadProducts() {
  const grid = document.getElementById('plpGrid');
  grid.innerHTML = '<div class="loading-center"><div class="spinner"></div></div>';
  const params = new URLSearchParams();
  if (plpState.search) params.set('search', plpState.search);
  if (plpState.category) params.set('category', plpState.category);
  if (plpState.brand.length) params.set('brand', plpState.brand.join(','));
  if (plpState.minRating) params.set('minRating', plpState.minRating);
  if (plpState.minDiscount) params.set('minDiscount', plpState.minDiscount);
  if (plpState.maxPrice) params.set('maxPrice', plpState.maxPrice);
  if (plpState.deal) params.set('deal', 1);
  params.set('sort', plpState.sort);
  params.set('page', plpState.page);
  params.set('limit', plpState.limit);

  document.getElementById('plpHeading').textContent = plpState.search
    ? `Results for "${plpState.search}"`
    : (plpState.deal ? 'Special Offers' : (SHOPKART_CATEGORIES.find(c => c._id === plpState.category)?.name || 'All Products'));

  try {
    const data = await api.get('/products?' + params.toString());
    buildBrandFilter(data.brands || []);
    document.getElementById('resultCount').textContent = `${data.total} product${data.total !== 1 ? 's' : ''} found`;
    grid.innerHTML = data.products.length
      ? data.products.map(productCardHtml).join('')
      : '<div class="empty-state"><h3>No products match your filters</h3><p style="margin-top:8px;">Try adjusting or resetting your filters.</p></div>';
    renderPagination(data.page, data.pages);
  } catch (e) {
    grid.innerHTML = '<div class="empty-state">Could not load products. Is the backend running and seeded?</div>';
    document.getElementById('resultCount').textContent = '';
  }
}

function renderPagination(page, pages) {
  const el = document.getElementById('plpPagination');
  if (pages <= 1) { el.innerHTML = ''; return; }
  let html = `<button ${page === 1 ? 'disabled' : ''} onclick="goToPage(${page - 1})">‹</button>`;
  for (let i = 1; i <= pages; i++) {
    html += `<button class="${i === page ? 'active' : ''}" onclick="goToPage(${i})">${i}</button>`;
  }
  html += `<button ${page === pages ? 'disabled' : ''} onclick="goToPage(${page + 1})">›</button>`;
  el.innerHTML = html;
}
function goToPage(p) {
  plpState.page = p;
  loadProducts();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
