/* Logic for product.html (PDP) */
let currentProduct = null;
let pdpTab = 'description';
let currentReviews = [];

(async function initPDP() {
  await renderShell();
  await refreshWishlistIds();
  const id = qs('id');
  if (!id) { showEmptyProduct(); return; }
  try {
    currentProduct = await api.get('/products/' + id);
    renderPDP();
    loadRelated();
    loadReviews();
  } catch (e) {
    showEmptyProduct();
  }
})();

function showEmptyProduct() {
  document.getElementById('pdpContainer').innerHTML = `
    <div class="empty-state"><h3>Product not found</h3><p style="margin-top:8px;">It may have been removed.</p>
    <a class="btn btn-primary" style="margin-top:16px;" href="products.html">Browse Products</a></div>`;
}

function stockLabel(stock) {
  if (stock <= 0) return `<span class="stock-out">Out of stock</span>`;
  if (stock <= 5) return `<span class="stock-low">Only ${stock} left — order soon</span>`;
  return `<span class="stock-ok">${ICONS.check} In stock, ready to ship</span>`;
}

const TABS = [
  { id: 'description', label: 'Description' },
  { id: 'specs', label: 'Specifications' },
  { id: 'offers', label: 'Available Offers' },
  { id: 'delivery', label: 'Delivery Info' },
  { id: 'reviews', label: 'Reviews' },
];

function tabPanelHtml(p) {
  if (pdpTab === 'description') return `<p>${p.description}</p>`;
  if (pdpTab === 'specs') {
    const specs = p.specifications || {};
    const entries = Object.entries(specs);
    return entries.length
      ? entries.map(([k, v]) => `<div class="spec-row"><span>${k}</span><b>${v}</b></div>`).join('')
      : '<p>No specifications listed for this product.</p>';
  }
  if (pdpTab === 'offers') {
    return `<ul style="margin:0;padding-left:18px;">
      <li>10% instant discount on select bank cards</li>
      <li>No cost EMI available on orders above ₹3,000</li>
      <li>Extra ₹100 off on your first ShopKart order</li>
    </ul>`;
  }
  if (pdpTab === 'delivery') {
    return `<p>Delivered in 2–5 business days depending on your location. Free delivery on orders above ₹499. Cash on Delivery available on eligible pincodes. Easy 7-day returns if the product is unused and in original packaging.</p>`;
  }
  if (pdpTab === 'reviews') {
    return renderReviewsSection();
  }
}

function renderReviewsSection() {
  const formHtml = isLoggedIn() ? `
    <div class="review-form">
      <b style="font-size:13.5px;">Write a review</b>
      <div class="star-input" id="reviewStars">
        ${[1,2,3,4,5].map(n => `<button type="button" data-star="${n}" onclick="setReviewStar(${n})">★</button>`).join('')}
      </div>
      <textarea id="reviewComment" placeholder="Share your experience with this product..."></textarea>
      <button class="btn btn-primary btn-sm" style="margin-top:10px;" onclick="submitReview()">Submit Review</button>
    </div>` : `<div class="review-form"><a href="login.html" class="link-btn">Log in</a> to write a review.</div>`;

  const list = currentReviews.length
    ? currentReviews.map(r => `
      <div class="review-card">
        <div class="review-top">
          <div class="avatar">${r.userName.split(' ').map(n=>n[0]).join('').slice(0,2)}</div>
          <div><div class="review-name">${r.userName}</div>${starsRow(r.rating)}</div>
        </div>
        <p class="review-text">${r.comment}</p>
      </div>`).join('')
    : '<p style="color:var(--ink-soft);">No reviews yet. Be the first to review this product!</p>';

  return formHtml + list;
}

let selectedReviewStar = 5;
function setReviewStar(n) {
  selectedReviewStar = n;
  document.querySelectorAll('#reviewStars button').forEach(b => {
    b.classList.toggle('active', Number(b.dataset.star) <= n);
  });
}

async function submitReview() {
  const comment = document.getElementById('reviewComment').value.trim();
  if (!comment) { showToast('Please write a short review', 'error'); return; }
  try {
    await api.post('/reviews/' + currentProduct._id, { rating: selectedReviewStar, comment });
    showToast('Thanks for your review!');
    await loadReviews();
    currentProduct = await api.get('/products/' + currentProduct._id); // refresh rating
    renderPDP();
    setTab('reviews');
  } catch (e) {
    showError(e);
  }
}

async function loadReviews() {
  try {
    currentReviews = await api.get('/reviews/' + currentProduct._id);
  } catch (e) { currentReviews = []; }
  if (pdpTab === 'reviews') renderTabOnly();
}

function setTab(id) {
  pdpTab = id;
  renderTabOnly();
}
function renderTabOnly() {
  const tabsWrap = document.getElementById('pdpTabsWrap');
  const panelWrap = document.getElementById('pdpTabPanel');
  if (!tabsWrap) return;
  tabsWrap.innerHTML = TABS.map(t => `<button class="tab-btn ${pdpTab === t.id ? 'active' : ''}" onclick="setTab('${t.id}')">${t.label}</button>`).join('');
  panelWrap.innerHTML = tabPanelHtml(currentProduct);
}

function renderPDP() {
  const p = currentProduct;
  const off = discountPercent(p.price, p.mrp);
  const wished = WISHLIST_IDS.includes(p._id);
  const catName = p.category?.name || '';
  const catId = p.category?._id || '';

  document.title = p.name + ' — ShopKart';
  document.getElementById('pdpContainer').innerHTML = `
    <div class="crumb">
      <a href="index.html">Home</a> / <a href="products.html?category=${catId}">${catName}</a> / ${p.name}
    </div>
    <div class="pdp-layout">
      <div>
        <div class="pdp-gallery-main" id="pdpMainImg">${productArt(p)}</div>
        <div class="pdp-thumbs">
          ${[0,1,2].map(i => `<div class="pdp-thumb ${i===0?'active':''}">${productArt(p)}</div>`).join('')}
        </div>
      </div>
      <div>
        <div class="pdp-title">${p.name}</div>
        <div class="pdp-brand">by ${p.brand}</div>
        <div class="rating-row" style="margin-top:10px;"><span class="rating-pill">${p.rating || '—'}${ICONS.star}</span><span class="count">${(p.numReviews||0).toLocaleString('en-IN')} ratings</span></div>
        <div class="pdp-price-block">
          <div class="pdp-price-now">${formatPrice(p.price)}
            ${p.mrp > p.price ? `<span class="price-was" style="font-size:16px;">${formatPrice(p.mrp)}</span><span class="price-off" style="font-size:14px;">${off}% off</span>` : ''}
          </div>
          <div style="margin-top:8px;">${stockLabel(p.stock)}</div>
        </div>

        <div class="pincode-row">
          <input type="text" id="pincodeInput" maxlength="6" placeholder="Enter delivery pincode">
          <button class="btn btn-ghost btn-sm" onclick="checkPincode()">Check</button>
        </div>
        <div class="pincode-result" id="pincodeResult"></div>

        <div class="qty-row">
          <span style="font-size:13.5px;font-weight:600;">Quantity</span>
          <div class="qty-ctrl"><button onclick="setPdpQty(-1)">−</button><span id="pdpQty">1</span><button onclick="setPdpQty(1)">+</button></div>
        </div>

        <div class="pdp-ctas">
          <button class="btn btn-outline" ${p.stock<1?'disabled':''} onclick="pdpAddToCart()">Add to Cart</button>
          <button class="btn btn-primary" ${p.stock<1?'disabled':''} onclick="pdpBuyNow()">Buy Now</button>
          <button class="wish-btn ${wished?'active':''}" style="position:static;box-shadow:none;border:1.5px solid var(--line);" onclick="handleWishlistToggle('${p._id}', this)">${wished?ICONS.heartFilled:ICONS.heart}</button>
        </div>

        <div class="offers-box">
          <h5>Available Offers</h5>
          <ul>
            <li>🏦 10% instant discount on select bank cards</li>
            <li>💳 No cost EMI available on orders above ₹3,000</li>
            <li>🎁 Extra ₹100 off on your first ShopKart order</li>
          </ul>
        </div>
      </div>
    </div>

    <div class="tabs" id="pdpTabsWrap"></div>
    <div class="tab-panel" id="pdpTabPanel"></div>

    <div class="section-head" style="margin-top:8px;"><div><h2 style="font-size:19px;">Related products</h2></div></div>
    <div class="prod-grid" id="relatedGrid"><div class="loading-center"><div class="spinner"></div></div></div>
  `;
  renderTabOnly();
}

function setPdpQty(delta) {
  const el = document.getElementById('pdpQty');
  let v = Math.max(1, parseInt(el.textContent) + delta);
  if (currentProduct && v > currentProduct.stock) v = currentProduct.stock || 1;
  el.textContent = v;
}
function getPdpQty() {
  const el = document.getElementById('pdpQty');
  return el ? parseInt(el.textContent) : 1;
}
async function pdpAddToCart() {
  if (!requireLogin('product.html?id=' + currentProduct._id)) return;
  try {
    await api.post('/cart', { productId: currentProduct._id, quantity: getPdpQty() });
    showToast('Added to cart');
    await updateHeaderBadges();
  } catch (e) { showError(e); }
}
async function pdpBuyNow() {
  if (!requireLogin('product.html?id=' + currentProduct._id)) return;
  try {
    await api.post('/cart', { productId: currentProduct._id, quantity: getPdpQty() });
    location.href = 'checkout.html';
  } catch (e) { showError(e); }
}

function checkPincode() {
  const val = document.getElementById('pincodeInput').value.trim();
  const resultEl = document.getElementById('pincodeResult');
  if (!/^\d{6}$/.test(val)) {
    resultEl.innerHTML = `<span style="color:var(--red);">Please enter a valid 6-digit pincode.</span>`;
    return;
  }
  // Simple simulated delivery estimate based on the pincode digits.
  const days = 2 + (Number(val[0]) % 4);
  const eta = new Date();
  eta.setDate(eta.getDate() + days);
  resultEl.innerHTML = `${ICONS.check} Delivery by <b>${eta.toLocaleDateString('en-IN', { day:'numeric', month:'short' })}</b> to ${val}. Cash on Delivery available.`;
}

async function loadRelated() {
  try {
    const data = await api.get('/products?category=' + (currentProduct.category?._id || '') + '&limit=5');
    const related = data.products.filter(p => p._id !== currentProduct._id).slice(0, 4);
    document.getElementById('relatedGrid').innerHTML = related.length
      ? related.map(productCardHtml).join('')
      : '<div class="empty-state">No related products found.</div>';
  } catch (e) {
    document.getElementById('relatedGrid').innerHTML = '';
  }
}
