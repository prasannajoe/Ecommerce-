/* Logic for cart.html */
let cartData = null;

(async function initCart() {
  await renderShell();
  await loadCart();
})();

async function loadCart() {
  const container = document.getElementById('cartContainer');
  if (!isLoggedIn()) {
    container.innerHTML = `
      <div class="crumb"><a href="index.html">Home</a> / Cart</div>
      <div class="empty-state"><h3>Please log in</h3><p style="margin-top:8px;">Log in to view and manage your cart.</p>
      <a class="btn btn-primary" style="margin-top:16px;" href="login.html?next=cart.html">Login</a></div>`;
    return;
  }
  try {
    cartData = await api.get('/cart');
    renderCart();
  } catch (e) {
    container.innerHTML = '<div class="empty-state">Could not load your cart.</div>';
  }
}

function renderCart() {
  const container = document.getElementById('cartContainer');
  const activeItems = cartData.items.filter(i => !i.savedForLater && i.product);
  const savedItems = cartData.items.filter(i => i.savedForLater && i.product);

  if (!activeItems.length && !savedItems.length) {
    container.innerHTML = `
      <div class="crumb"><a href="index.html">Home</a> / Cart</div>
      <div class="empty-state"><h3>Your cart is empty</h3><p style="margin-top:8px;">Add some products to get started.</p>
      <a class="btn btn-primary" style="margin-top:16px;" href="products.html">Browse Products</a></div>`;
    return;
  }

  const subtotal = activeItems.reduce((s, i) => s + i.product.price * i.quantity, 0);
  const mrpTotal = activeItems.reduce((s, i) => s + i.product.mrp * i.quantity, 0);
  const discount = mrpTotal - subtotal;
  const delivery = subtotal >= 499 || subtotal === 0 ? 0 : 49;
  const total = subtotal + delivery;

  container.innerHTML = `
    <div class="crumb"><a href="index.html">Home</a> / Cart</div>
    <div class="section-head"><div><h2>Your Cart</h2><p>${activeItems.length} item${activeItems.length !== 1 ? 's' : ''} in your cart</p></div></div>
    <div class="cart-layout">
      <div>
        ${activeItems.length ? activeItems.map(i => cartItemHtml(i, false)).join('') : '<p style="color:var(--ink-soft);padding:16px 0;">No items in your cart — check "Saved for later" below.</p>'}
        ${savedItems.length ? `<div class="saved-later-title">Saved for later (${savedItems.length})</div>${savedItems.map(i => cartItemHtml(i, true)).join('')}` : ''}
      </div>
      <div class="summary-box">
        <h4 style="margin-bottom:14px;">Price Details</h4>
        <div class="summary-row"><span>Price (${activeItems.reduce((s,i)=>s+i.quantity,0)} items)</span><b>${formatPrice(mrpTotal)}</b></div>
        <div class="summary-row"><span>Discount</span><b style="color:var(--green);">${discount>0?'− '+formatPrice(discount):'₹0'}</b></div>
        <div class="summary-row"><span>Delivery Charge</span><b>${delivery === 0 ? 'FREE' : formatPrice(delivery)}</b></div>
        <div class="summary-total"><span>Total Amount</span><span>${formatPrice(total)}</span></div>
        <button class="btn btn-primary btn-block" style="margin-top:18px;" ${!activeItems.length?'disabled':''} onclick="location.href='checkout.html'">Proceed to Checkout</button>
      </div>
    </div>`;
}

function cartItemHtml(item, saved) {
  const p = item.product;
  return `
  <div class="cart-item">
    <div class="cart-item-media">${productArt(p)}</div>
    <div class="cart-item-info">
      <h4>${p.name}</h4>
      <span>${formatPrice(p.price)} each · ${p.stock < 1 ? '<b style="color:var(--red);">Out of stock</b>' : `${p.stock} in stock`}</span>
    </div>
    <div class="cart-item-right">
      ${saved ? `<span style="font-size:13px;font-weight:600;">${formatPrice(p.price * item.quantity)}</span>` : `
      <div class="qty-ctrl">
        <button onclick="changeQty('${p._id}', ${item.quantity - 1})">−</button>
        <span>${item.quantity}</span>
        <button onclick="changeQty('${p._id}', ${item.quantity + 1})" ${item.quantity >= p.stock ? 'disabled' : ''}>+</button>
      </div>`}
      <div class="cart-links">
        <button class="save-link" onclick="toggleSaveForLater('${p._id}')">${saved ? 'Move to cart' : 'Save for later'}</button>
        <button class="remove-link" onclick="removeItem('${p._id}')">Remove</button>
      </div>
    </div>
  </div>`;
}

async function changeQty(productId, qty) {
  if (qty < 1) return;
  try {
    cartData = await api.put('/cart/' + productId, { quantity: qty });
    renderCart();
    updateHeaderBadges();
  } catch (e) { showError(e); }
}
async function removeItem(productId) {
  try {
    cartData = await api.del('/cart/' + productId);
    renderCart();
    updateHeaderBadges();
    showToast('Item removed');
  } catch (e) { showError(e); }
}
async function toggleSaveForLater(productId) {
  try {
    cartData = await api.put('/cart/' + productId + '/save-for-later');
    renderCart();
    updateHeaderBadges();
  } catch (e) { showError(e); }
}
