/* Logic for account.html — profile, orders, tracking, wishlist, addresses, logout */
let accTab = qs('tab') || 'profile';

(async function initAccount() {
  await renderShell();
  if (!isLoggedIn()) {
    document.getElementById('accSide').innerHTML = '';
    document.getElementById('accContent').innerHTML = `
      <div class="empty-state"><h3>Please log in</h3><p style="margin-top:8px;">Log in to view your account.</p>
      <a class="btn btn-primary" style="margin-top:16px;" href="login.html?next=account.html">Login</a></div>`;
    return;
  }
  renderSidebar();
  loadTab();
})();

const TABS = [
  { id: 'profile', label: 'Profile', icon: ICONS.user },
  { id: 'orders', label: 'My Orders', icon: ICONS.cart },
  { id: 'wishlist', label: 'Wishlist', icon: ICONS.heart },
  { id: 'addresses', label: 'Saved Addresses', icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>` },
];

function renderSidebar() {
  const user = getUser();
  document.getElementById('accSide').innerHTML = `
    <div style="padding:16px;border-bottom:1px solid var(--line);">
      <b style="font-size:14px;">${user?.name || 'Account'}</b>
      <p style="font-size:12px;color:var(--ink-soft);margin-top:2px;">${user?.email || ''}</p>
    </div>
    ${TABS.map(t => `<a href="#" class="${accTab===t.id?'active':''}" onclick="setAccTab('${t.id}');return false;">${t.icon}${t.label}</a>`).join('')}
    <a href="#" onclick="logout();return false;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg>Logout</a>
  `;
}
function setAccTab(id) {
  accTab = id;
  renderSidebar();
  loadTab();
}

async function loadTab() {
  const content = document.getElementById('accContent');
  content.innerHTML = '<div class="loading-center"><div class="spinner"></div></div>';
  if (accTab === 'profile') return renderProfile();
  if (accTab === 'orders') return renderOrders();
  if (accTab === 'wishlist') return renderWishlistTab();
  if (accTab === 'addresses') return renderAddressesTab();
}

function renderProfile() {
  const user = getUser();
  document.getElementById('accContent').innerHTML = `
    <div class="form-card">
      <h3>Personal Information</h3>
      <div class="form-grid">
        <div class="field"><label>Full Name</label><input type="text" value="${user?.name || ''}" disabled></div>
        <div class="field"><label>Email</label><input type="email" value="${user?.email || ''}" disabled></div>
      </div>
      <div class="form-grid" style="margin-top:14px;">
        <div class="field"><label>Phone Number</label><input type="text" value="${user?.phone || 'Not added'}" disabled></div>
        <div class="field"><label>Account Type</label><input type="text" value="${user?.role === 'admin' ? 'Administrator' : 'Customer'}" disabled></div>
      </div>
      <p style="font-size:12px;color:var(--ink-soft);margin-top:14px;">Profile editing isn't wired up in this demo — but the form above shows how it would look.</p>
    </div>`;
}

async function renderOrders() {
  const content = document.getElementById('accContent');
  try {
    const orders = await api.get('/orders');
    if (!orders.length) {
      content.innerHTML = `<div class="empty-state"><h3>No orders yet</h3><p style="margin-top:8px;">When you place an order, it'll show up here.</p>
        <a class="btn btn-primary" style="margin-top:16px;" href="products.html">Start Shopping</a></div>`;
      return;
    }
    content.innerHTML = orders.map(o => orderCardHtml(o)).join('');
  } catch (e) {
    content.innerHTML = '<div class="empty-state">Could not load your orders.</div>';
  }
}
function statusClass(status) {
  return 'status-' + status.toLowerCase().replace(/\s+/g, '');
}
function orderCardHtml(o) {
  const steps = ['Placed', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered'];
  const currentIdx = steps.indexOf(o.orderStatus);
  return `
  <div class="order-card">
    <div class="order-card-top">
      <div><b style="font-size:13.5px;">#${o.orderNumber}</b><p style="font-size:12px;color:var(--ink-soft);">${new Date(o.createdAt).toLocaleDateString('en-IN', {day:'numeric',month:'short',year:'numeric'})} · ${o.items.length} item${o.items.length!==1?'s':''}</p></div>
      <span class="status-pill ${statusClass(o.orderStatus)}">${o.orderStatus}</span>
    </div>
    <div style="display:flex;gap:10px;overflow-x:auto;margin-bottom:10px;">
      ${o.items.map(i => `<div style="width:46px;height:46px;background:var(--mist);border-radius:8px;flex-shrink:0;display:flex;align-items:center;justify-content:center;padding:6px;">${productArt({name:i.name, images:[i.image]})}</div>`).join('')}
    </div>
    ${o.orderStatus !== 'Cancelled' ? `
    <div class="track-steps" style="margin:18px 0 10px;">
      ${steps.map((s,idx) => `<div class="track-step"><div class="track-dot ${idx<=currentIdx?'done':''}">${idx<=currentIdx?ICONS.check:idx+1}</div><span>${s}</span></div>`).join('')}
    </div>` : ''}
    <div style="display:flex;justify-content:space-between;align-items:center;font-size:13px;">
      <span style="color:var(--ink-soft);">Total: <b style="color:var(--ink);">${formatPrice(o.totalPrice)}</b></span>
      <span style="color:var(--ink-soft);">Payment: ${o.paymentMethod} (${o.paymentStatus})</span>
    </div>
  </div>`;
}

async function renderWishlistTab() {
  const content = document.getElementById('accContent');
  try {
    await refreshWishlistIds();
    const wl = await api.get('/wishlist');
    const products = wl.products || [];
    content.innerHTML = products.length
      ? `<div class="prod-grid">${products.map(productCardHtml).join('')}</div>`
      : `<div class="empty-state"><h3>Your wishlist is empty</h3><a class="btn btn-primary" style="margin-top:16px;" href="products.html">Browse Products</a></div>`;
  } catch (e) {
    content.innerHTML = '<div class="empty-state">Could not load wishlist.</div>';
  }
}

let accAddresses = [];
async function renderAddressesTab() {
  const content = document.getElementById('accContent');
  try {
    accAddresses = await api.get('/addresses');
    content.innerHTML = `
      <div class="section-head" style="margin-bottom:14px;"><div><h3 style="font-size:16px;">Saved Addresses</h3></div>
        <button class="btn btn-ghost btn-sm" onclick="document.getElementById('accAddrForm').classList.toggle('hidden')">+ Add Address</button>
      </div>
      <div id="accAddrForm" class="form-card hidden">
        <div class="form-grid">
          <div class="field"><label>Full Name</label><input id="aa_name" type="text"></div>
          <div class="field"><label>Phone</label><input id="aa_phone" type="tel"></div>
        </div>
        <div class="form-grid full" style="margin-top:14px;"><div class="field"><label>Address</label><textarea id="aa_address"></textarea></div></div>
        <div class="form-grid" style="margin-top:14px;">
          <div class="field"><label>City</label><input id="aa_city" type="text"></div>
          <div class="field"><label>State</label><input id="aa_state" type="text"></div>
        </div>
        <div class="form-grid" style="margin-top:14px;">
          <div class="field"><label>Pincode</label><input id="aa_pincode" type="text" maxlength="6"></div>
          <div class="field"><label>Type</label><select id="aa_type"><option>Home</option><option>Work</option><option>Other</option></select></div>
        </div>
        <button class="btn btn-primary btn-sm" style="margin-top:14px;" onclick="addAccAddress()">Save Address</button>
      </div>
      <div id="accAddrList">${accAddresses.map(a => accAddrCardHtml(a)).join('') || '<p style="color:var(--ink-soft);">No saved addresses yet.</p>'}</div>
    `;
  } catch (e) {
    content.innerHTML = '<div class="empty-state">Could not load addresses.</div>';
  }
}
function accAddrCardHtml(a) {
  return `
  <div class="addr-card">
    <b>${a.fullName} · ${a.type} ${a.isDefault ? '<span style="color:var(--blue);">(Default)</span>' : ''}</b>
    <p>${a.addressLine}, ${a.city}, ${a.state} - ${a.pincode}</p>
    <p>Phone: ${a.phone}</p>
    <div style="display:flex;gap:14px;margin-top:8px;">
      ${!a.isDefault ? `<button class="save-link" onclick="setDefaultAddress('${a._id}')">Set as default</button>` : ''}
      <button class="remove-link" onclick="deleteAccAddress('${a._id}')">Delete</button>
    </div>
  </div>`;
}
async function addAccAddress() {
  const fullName = document.getElementById('aa_name').value.trim();
  const phone = document.getElementById('aa_phone').value.trim();
  const addressLine = document.getElementById('aa_address').value.trim();
  const city = document.getElementById('aa_city').value.trim();
  const state = document.getElementById('aa_state').value.trim();
  const pincode = document.getElementById('aa_pincode').value.trim();
  const type = document.getElementById('aa_type').value;
  if (!fullName || !phone || !addressLine || !city || !state || !pincode) { showToast('Please fill all fields', 'error'); return; }
  if (!/^\d{10}$/.test(phone)) { showToast('Phone must be 10 digits', 'error'); return; }
  if (!/^\d{6}$/.test(pincode)) { showToast('Pincode must be 6 digits', 'error'); return; }
  try {
    await api.post('/addresses', { fullName, phone, addressLine, city, state, pincode, type });
    showToast('Address added');
    renderAddressesTab();
  } catch (e) { showError(e); }
}
async function setDefaultAddress(id) {
  try { await api.put('/addresses/' + id, { isDefault: true }); renderAddressesTab(); } catch (e) { showError(e); }
}
async function deleteAccAddress(id) {
  try { await api.del('/addresses/' + id); showToast('Address removed'); renderAddressesTab(); } catch (e) { showError(e); }
}
