/* Admin: manage products (list, add, edit, delete, image upload) */
let adminProductsCache = [];
let adminCategoriesCache = [];
let editingProductId = null;
let uploadedImageUrl = '';

(async function initAdminProducts() {
  if (!adminGuard()) return;
  renderAdminShell('products');
  await loadAdminProducts();
})();

async function loadAdminProducts() {
  const main = document.getElementById('adminMain');
  main.innerHTML = '<div class="loading-center"><div class="spinner"></div></div>';
  try {
    const [data, cats] = await Promise.all([api.get('/products?limit=200'), api.get('/categories')]);
    adminProductsCache = data.products;
    adminCategoriesCache = cats;
    renderAdminProducts();
  } catch (e) {
    main.innerHTML = '<div class="empty-state">Could not load products.</div>';
  }
}

function renderAdminProducts() {
  const main = document.getElementById('adminMain');
  main.innerHTML = `
    <div class="admin-topbar"><h1>Manage Products</h1><button class="btn btn-primary btn-sm" onclick="openProductModal()">+ Add Product</button></div>
    <div class="admin-panel" style="padding:0;">
      <div class="table-wrap"><table class="admin-table">
        <thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th>Rating</th><th>Actions</th></tr></thead>
        <tbody>
          ${adminProductsCache.map(p => `<tr>
            <td style="display:flex;align-items:center;gap:10px;"><div class="mini-table-img">${productArt(p)}</div>${p.name}</td>
            <td>${p.category?.name || '—'}</td>
            <td>${formatPrice(p.price)}</td>
            <td>${p.stock <= 5 ? `<b style="color:var(--red);">${p.stock}</b>` : p.stock}</td>
            <td>${p.rating || '—'} ★</td>
            <td>
              <button class="icon-btn" title="Edit" onclick="openProductModal('${p._id}')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5Z"/></svg></button>
              <button class="icon-btn danger" title="Delete" onclick="deleteAdminProduct('${p._id}')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m2 0v14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V6h12Z"/></svg></button>
            </td>
          </tr>`).join('') || '<tr><td colspan="6" style="color:var(--ink-soft);">No products yet. Add your first product, or run the seed script.</td></tr>'}
        </tbody>
      </table></div>
    </div>
  `;
}

function openProductModal(productId) {
  editingProductId = productId || null;
  uploadedImageUrl = '';
  const p = productId ? adminProductsCache.find(x => x._id === productId) : null;
  const backdrop = document.createElement('div');
  backdrop.className = 'admin-modal-backdrop';
  backdrop.id = 'productModalBackdrop';
  backdrop.innerHTML = `
    <div class="admin-modal">
      <h3>${p ? 'Edit Product' : 'Add New Product'}</h3>
      <div class="field" style="margin-bottom:12px;"><label>Product Name</label><input id="pm_name" type="text" value="${p ? p.name.replace(/"/g,'&quot;') : ''}"></div>
      <div class="form-grid" style="margin-bottom:12px;">
        <div class="field"><label>Brand</label><input id="pm_brand" type="text" value="${p ? p.brand : ''}"></div>
        <div class="field"><label>Category</label>
          <select id="pm_category">${adminCategoriesCache.map(c => `<option value="${c._id}" ${p && p.category?._id===c._id ? 'selected':''}>${c.name}</option>`).join('')}</select>
        </div>
      </div>
      <div class="form-grid" style="margin-bottom:12px;">
        <div class="field"><label>Price (₹)</label><input id="pm_price" type="number" value="${p ? p.price : ''}"></div>
        <div class="field"><label>MRP (₹)</label><input id="pm_mrp" type="number" value="${p ? p.mrp : ''}"></div>
      </div>
      <div class="form-grid" style="margin-bottom:12px;">
        <div class="field"><label>Stock Quantity</label><input id="pm_stock" type="number" value="${p ? p.stock : ''}"></div>
        <div class="field"><label>Product Image</label><input id="pm_image" type="file" accept="image/*" onchange="handleAdminImageUpload(event)"></div>
      </div>
      <div class="field" style="margin-bottom:16px;"><label>Description</label><textarea id="pm_desc" style="min-height:70px;">${p ? p.description : ''}</textarea></div>
      <div style="display:flex;gap:10px;justify-content:flex-end;">
        <button class="btn btn-ghost btn-sm" onclick="closeProductModal()">Cancel</button>
        <button class="btn btn-primary btn-sm" onclick="saveAdminProduct()">${p ? 'Save Changes' : 'Add Product'}</button>
      </div>
    </div>`;
  document.body.appendChild(backdrop);
}
function closeProductModal() {
  const el = document.getElementById('productModalBackdrop');
  if (el) el.remove();
}
async function handleAdminImageUpload(e) {
  const file = e.target.files[0];
  if (!file) return;
  const formData = new FormData();
  formData.append('image', file);
  try {
    const res = await fetch(API_BASE + '/upload', { method: 'POST', headers: { Authorization: 'Bearer ' + getToken() }, body: formData });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message);
    uploadedImageUrl = data.url;
    showToast('Image uploaded');
  } catch (err) {
    showError(err);
  }
}
async function saveAdminProduct() {
  const name = document.getElementById('pm_name').value.trim();
  const brand = document.getElementById('pm_brand').value.trim();
  const category = document.getElementById('pm_category').value;
  const price = Number(document.getElementById('pm_price').value);
  const mrp = Number(document.getElementById('pm_mrp').value);
  const stock = Number(document.getElementById('pm_stock').value);
  const description = document.getElementById('pm_desc').value.trim();

  if (!name || !brand || !category || !price || !mrp || !description) {
    showToast('Please fill in all required fields', 'error'); return;
  }
  const payload = { name, brand, category, price, mrp, stock, description };
  if (uploadedImageUrl) payload.images = [uploadedImageUrl];

  try {
    if (editingProductId) await api.put('/products/' + editingProductId, payload);
    else await api.post('/products', payload);
    showToast(editingProductId ? 'Product updated' : 'Product added');
    closeProductModal();
    await loadAdminProducts();
  } catch (e) { showError(e); }
}
async function deleteAdminProduct(id) {
  if (!confirm('Delete this product? This cannot be undone.')) return;
  try {
    await api.del('/products/' + id);
    showToast('Product deleted');
    await loadAdminProducts();
  } catch (e) { showError(e); }
}
