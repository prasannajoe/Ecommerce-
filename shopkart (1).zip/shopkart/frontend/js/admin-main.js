/* Shared shell for all admin/*.html pages. Include after api.js + main.js. */
function adminGuard() {
  if (!isLoggedIn() || !isAdmin()) {
    location.href = 'login.html';
    return false;
  }
  return true;
}

const ADMIN_NAV = [
  { id: 'dashboard', label: 'Dashboard', href: 'dashboard.html', icon: `<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>` },
  { id: 'products', label: 'Products', href: 'products.html', icon: `<path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-14L4 7m8 4v10M4 7v10l8 4"/>` },
  { id: 'categories', label: 'Categories', href: 'categories.html', icon: `<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>` },
  { id: 'orders', label: 'Orders', href: 'orders.html', icon: `<path d="M6 2l1 14a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-14"/><path d="M3 6h18"/>` },
  { id: 'users', label: 'Customers', href: 'users.html', icon: `<circle cx="9" cy="8" r="4"/><path d="M2 21v-2a5 5 0 0 1 5-5h4a5 5 0 0 1 5 5v2"/>` },
];

function renderAdminShell(activeId) {
  document.body.classList.add('admin-body');
  const shell = document.getElementById('admin-shell');
  shell.innerHTML = `
    <aside class="admin-side">
      <div class="admin-logo">Shop<span>Kart</span> Admin</div>
      ${ADMIN_NAV.map(n => `<a href="${n.href}" class="${activeId===n.id?'active':''}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">${n.icon}</svg>${n.label}</a>`).join('')}
      <div class="divider"></div>
      <a href="../index.html"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 19l-7-7 7-7M3 12h18"/></svg>Exit to Storefront</a>
      <a href="#" onclick="logout();return false;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg>Logout</a>
    </aside>
    <div class="admin-main" id="adminMain"></div>
  `;
}
