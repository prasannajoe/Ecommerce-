/* Logic for checkout.html */
let checkoutCart = null;
let checkoutAddresses = [];
let selectedAddressId = null;
let selectedPayment = 'COD';

(async function initCheckout() {
  await renderShell();
  const container = document.getElementById('checkoutContainer');
  if (!isLoggedIn()) {
    container.innerHTML = `<div class="empty-state"><h3>Please log in</h3><p style="margin-top:8px;">Log in to continue to checkout.</p>
      <a class="btn btn-primary" style="margin-top:16px;" href="login.html?next=checkout.html">Login</a></div>`;
    return;
  }
  try {
    [checkoutCart, checkoutAddresses] = await Promise.all([api.get('/cart'), api.get('/addresses')]);
  } catch (e) {
    container.innerHTML = '<div class="empty-state">Could not load checkout details.</div>';
    return;
  }
  const activeItems = checkoutCart.items.filter(i => !i.savedForLater && i.product);
  if (!activeItems.length) {
    container.innerHTML = `<div class="empty-state"><h3>Your cart is empty</h3><p style="margin-top:8px;">Add products before checking out.</p>
      <a class="btn btn-primary" style="margin-top:16px;" href="products.html">Browse Products</a></div>`;
    return;
  }
  const defaultAddr = checkoutAddresses.find(a => a.isDefault) || checkoutAddresses[0];
  selectedAddressId = defaultAddr ? defaultAddr._id : null;
  renderCheckout();
})();

function priceBreakdown() {
  const activeItems = checkoutCart.items.filter(i => !i.savedForLater && i.product);
  const subtotal = activeItems.reduce((s, i) => s + i.product.price * i.quantity, 0);
  const mrpTotal = activeItems.reduce((s, i) => s + i.product.mrp * i.quantity, 0);
  const discount = mrpTotal - subtotal;
  const delivery = subtotal >= 499 ? 0 : 49;
  const total = subtotal + delivery;
  return { activeItems, subtotal, discount, delivery, total };
}

function renderCheckout() {
  const { activeItems, subtotal, discount, delivery, total } = priceBreakdown();
  const container = document.getElementById('checkoutContainer');

  container.innerHTML = `
    <div class="crumb"><a href="index.html">Home</a> / <a href="cart.html">Cart</a> / Checkout</div>
    <div class="section-head"><div><h2>Checkout</h2></div></div>
    <div class="checkout-layout">
      <div>
        <div class="form-card">
          <h3>Delivery Address</h3>
          <div id="addressList">
            ${checkoutAddresses.map(a => addressCardHtml(a)).join('') || '<p style="color:var(--ink-soft);font-size:13px;">No saved addresses yet — add one below.</p>'}
          </div>
          <button class="btn btn-ghost btn-sm" style="margin-top:8px;" onclick="toggleNewAddressForm()">+ Add New Address</button>
          <div id="newAddressForm" class="hidden" style="margin-top:16px;">
            <div class="form-grid">
              <div class="field"><label>Full Name</label><input id="af_name" type="text" placeholder="e.g. Anjali Rao"></div>
              <div class="field"><label>Phone Number</label><input id="af_phone" type="tel" placeholder="10-digit mobile number"></div>
            </div>
            <div class="form-grid full" style="margin-top:14px;">
              <div class="field"><label>Address</label><textarea id="af_address" placeholder="House no, street, area"></textarea></div>
            </div>
            <div class="form-grid" style="margin-top:14px;">
              <div class="field"><label>City</label><input id="af_city" type="text"></div>
              <div class="field"><label>State</label><input id="af_state" type="text"></div>
            </div>
            <div class="form-grid" style="margin-top:14px;">
              <div class="field"><label>Pincode</label><input id="af_pincode" type="text" maxlength="6"></div>
              <div class="field"><label>Type</label>
                <select id="af_type"><option>Home</option><option>Work</option><option>Other</option></select>
              </div>
            </div>
            <button class="btn btn-primary btn-sm" style="margin-top:14px;" onclick="saveNewAddress()">Save Address</button>
          </div>
        </div>

        <div class="form-card">
          <h3>Payment Method</h3>
          ${paymentOptionHtml('UPI', 'UPI', 'Pay using any UPI app')}
          ${paymentOptionHtml('Card', 'Credit / Debit Card', 'Visa, Mastercard, RuPay & more')}
          ${paymentOptionHtml('NetBanking', 'Net Banking', 'All major Indian banks supported')}
          ${paymentOptionHtml('COD', 'Cash on Delivery', 'Pay when your order arrives')}
        </div>
      </div>
      <div class="summary-box">
        <h4 style="margin-bottom:14px;">Order Summary</h4>
        ${activeItems.map(i => `<div class="summary-row"><span>${i.product.name} × ${i.quantity}</span><b>${formatPrice(i.product.price * i.quantity)}</b></div>`).join('')}
        <div class="summary-row" style="border-top:1px solid var(--line);padding-top:12px;"><span>Subtotal</span><b>${formatPrice(subtotal)}</b></div>
        <div class="summary-row"><span>Discount</span><b style="color:var(--green);">${discount>0?'− '+formatPrice(discount):'₹0'}</b></div>
        <div class="summary-row"><span>Delivery</span><b>${delivery===0?'FREE':formatPrice(delivery)}</b></div>
        <div class="summary-total"><span>Total</span><span>${formatPrice(total)}</span></div>
        <button class="btn btn-primary btn-block" style="margin-top:18px;" id="placeOrderBtn" onclick="placeOrder()">Place Order</button>
        <p id="checkoutError" style="color:var(--red);font-size:12.5px;margin-top:10px;"></p>
      </div>
    </div>`;
}

function addressCardHtml(a) {
  const selected = a._id === selectedAddressId;
  return `
  <div class="addr-card ${selected ? 'selected' : ''}" onclick="selectAddress('${a._id}')">
    <b>${a.fullName} · ${a.type}</b>
    <p>${a.addressLine}, ${a.city}, ${a.state} - ${a.pincode}</p>
    <p>Phone: ${a.phone}</p>
  </div>`;
}
function selectAddress(id) {
  selectedAddressId = id;
  document.getElementById('addressList').innerHTML = checkoutAddresses.map(a => addressCardHtml(a)).join('');
}
function toggleNewAddressForm() {
  document.getElementById('newAddressForm').classList.toggle('hidden');
}
async function saveNewAddress() {
  const fullName = document.getElementById('af_name').value.trim();
  const phone = document.getElementById('af_phone').value.trim();
  const addressLine = document.getElementById('af_address').value.trim();
  const city = document.getElementById('af_city').value.trim();
  const state = document.getElementById('af_state').value.trim();
  const pincode = document.getElementById('af_pincode').value.trim();
  const type = document.getElementById('af_type').value;

  if (!fullName || !phone || !addressLine || !city || !state || !pincode) {
    showToast('Please fill in all address fields', 'error'); return;
  }
  if (!/^\d{10}$/.test(phone)) { showToast('Phone number must be 10 digits', 'error'); return; }
  if (!/^\d{6}$/.test(pincode)) { showToast('Pincode must be 6 digits', 'error'); return; }

  try {
    const addr = await api.post('/addresses', { fullName, phone, addressLine, city, state, pincode, type, isDefault: checkoutAddresses.length === 0 });
    checkoutAddresses.push(addr);
    selectedAddressId = addr._id;
    renderCheckout();
    showToast('Address saved');
  } catch (e) { showError(e); }
}

function paymentOptionHtml(value, label, desc) {
  const selected = selectedPayment === value;
  return `
  <label class="pay-opt ${selected ? 'selected' : ''}" onclick="selectPayment('${value}')">
    <input type="radio" name="pay" ${selected ? 'checked' : ''}>
    <div><b>${label}</b><span>${desc}</span></div>
  </label>`;
}
function selectPayment(value) {
  selectedPayment = value;
  renderCheckout();
}

async function placeOrder() {
  const errorEl = document.getElementById('checkoutError');
  errorEl.textContent = '';
  if (!selectedAddressId) { errorEl.textContent = 'Please select or add a delivery address.'; return; }
  const address = checkoutAddresses.find(a => a._id === selectedAddressId);

  const btn = document.getElementById('placeOrderBtn');
  btn.disabled = true;
  btn.textContent = 'Placing order...';
  try {
    const order = await api.post('/orders', {
      shippingAddress: {
        fullName: address.fullName, phone: address.phone, pincode: address.pincode,
        addressLine: address.addressLine, city: address.city, state: address.state,
      },
      paymentMethod: selectedPayment,
    });
    location.href = 'order-confirmation.html?orderId=' + order._id;
  } catch (e) {
    errorEl.textContent = e.message;
    btn.disabled = false;
    btn.textContent = 'Place Order';
  }
}
