/* Admin: view all orders and update their status */
let adminOrdersCache = [];

(async function initAdminOrders() {
  if (!adminGuard()) return;
  renderAdminShell('orders');
  await loadAdminOrders();
})();

async function loadAdminOrders() {
  const main = document.getElementById('adminMain');
  main.innerHTML = '<div class="loading-center"><div class="spinner"></div></div>';
  try {
    adminOrdersCache = await api.get('/orders/admin/all');
    renderAdminOrders();
  } catch (e) {
    main.innerHTML = '<div class="empty-state">Could not load orders.</div>';
  }
}

const ORDER_STATUSES = ['Placed', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered', 'Cancelled'];

function renderAdminOrders() {
  const main = document.getElementById('adminMain');
  main.innerHTML = `
    <div class="admin-topbar"><h1>Manage Orders</h1><span style="font-size:12.5px;color:var(--ink-soft);">${adminOrdersCache.length} total orders</span></div>
    <div class="admin-panel" style="padding:0;">
      <div class="table-wrap"><table class="admin-table">
        <thead><tr><th>Order ID</th><th>Customer</th><th>Items</th><th>Total</th><th>Payment</th><th>Date</th><th>Status</th></tr></thead>
        <tbody>
          ${adminOrdersCache.map(o => `<tr>
            <td>#${o.orderNumber}</td>
            <td>${o.user?.name || '—'}<br><span style="color:var(--ink-soft);font-size:11.5px;">${o.user?.email || ''}</span></td>
            <td>${o.items.length}</td>
            <td>${formatPrice(o.totalPrice)}</td>
            <td>${o.paymentMethod} <span style="color:var(--ink-soft);">(${o.paymentStatus})</span></td>
            <td>${new Date(o.createdAt).toLocaleDateString('en-IN')}</td>
            <td>
              <select class="status-select" onchange="updateAdminOrderStatus('${o._id}', this.value)">
                ${ORDER_STATUSES.map(s => `<option value="${s}" ${o.orderStatus===s?'selected':''}>${s}</option>`).join('')}
              </select>
            </td>
          </tr>`).join('') || '<tr><td colspan="7" style="color:var(--ink-soft);">No orders placed yet.</td></tr>'}
        </tbody>
      </table></div>
    </div>`;
}

async function updateAdminOrderStatus(orderId, status) {
  try {
    await api.put('/orders/' + orderId + '/status', { status });
    showToast('Order status updated');
    const order = adminOrdersCache.find(o => o._id === orderId);
    if (order) order.orderStatus = status;
  } catch (e) { showError(e); }
}
