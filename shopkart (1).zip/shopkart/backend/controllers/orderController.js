const Order = require('../models/Order');
const OrderItem = require('../models/OrderItem');
const Payment = require('../models/Payment');
const Cart = require('../models/Cart');
const Product = require('../models/Product');

function generateOrderNumber() {
  return 'SK' + Date.now().toString().slice(-8) + Math.floor(Math.random() * 900 + 100);
}

// POST /api/orders   { shippingAddress, paymentMethod }
// Creates an order from the user's current cart.
exports.createOrder = async (req, res, next) => {
  try {
    const { shippingAddress, paymentMethod } = req.body;
    if (!shippingAddress || !paymentMethod) {
      return res.status(400).json({ message: 'Shipping address and payment method are required.' });
    }

    const cart = await Cart.findOne({ user: req.user._id }).populate('items.product');
    const activeItems = cart ? cart.items.filter((i) => !i.savedForLater) : [];
    if (!activeItems.length) {
      return res.status(400).json({ message: 'Your cart is empty.' });
    }

    // Verify stock and build snapshot line items.
    const orderItems = [];
    let itemsPrice = 0;
    for (const item of activeItems) {
      const product = item.product;
      if (!product) continue;
      if (product.stock < item.quantity) {
        return res.status(400).json({ message: `${product.name} does not have enough stock.` });
      }
      orderItems.push({
        product: product._id, name: product.name,
        image: product.images[0], price: product.price, quantity: item.quantity,
      });
      itemsPrice += product.price * item.quantity;
    }

    const discount = 0; // coupon logic could plug in here
    const deliveryCharge = itemsPrice >= 499 ? 0 : 49;
    const totalPrice = itemsPrice - discount + deliveryCharge;

    const order = await Order.create({
      orderNumber: generateOrderNumber(),
      user: req.user._id,
      items: orderItems,
      shippingAddress,
      paymentMethod,
      paymentStatus: paymentMethod === 'COD' ? 'Pending' : 'Paid',
      itemsPrice, discount, deliveryCharge, totalPrice,
      orderStatus: 'Placed',
      statusHistory: [{ status: 'Placed' }],
    });

    // Mirror into OrderItem collection.
    await OrderItem.insertMany(
      orderItems.map((i) => ({ order: order._id, ...i }))
    );

    // Record payment (simulated).
    await Payment.create({
      order: order._id, user: req.user._id, method: paymentMethod,
      amount: totalPrice, status: paymentMethod === 'COD' ? 'Pending' : 'Success',
      transactionId: paymentMethod === 'COD' ? undefined : 'TXN' + Date.now(),
    });

    // Reduce stock.
    for (const item of orderItems) {
      await Product.findByIdAndUpdate(item.product, { $inc: { stock: -item.quantity } });
    }

    // Clear only the items that were part of this order (leave "saved for later" items).
    cart.items = cart.items.filter((i) => i.savedForLater);
    await cart.save();

    res.status(201).json(order);
  } catch (error) {
    next(error);
  }
};

// GET /api/orders  (current user's orders)
exports.getMyOrders = async (req, res, next) => {
  try {
    const orders = await Order.find({ user: req.user._id }).sort('-createdAt');
    res.json(orders);
  } catch (error) {
    next(error);
  }
};

// GET /api/orders/:id
exports.getOrderById = async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'Order not found.' });
    const isOwner = order.user.toString() === req.user._id.toString();
    if (!isOwner && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to view this order.' });
    }
    res.json(order);
  } catch (error) {
    next(error);
  }
};

// GET /api/orders/admin/all  (admin)
exports.getAllOrders = async (req, res, next) => {
  try {
    const orders = await Order.find().populate('user', 'name email').sort('-createdAt');
    res.json(orders);
  } catch (error) {
    next(error);
  }
};

// PUT /api/orders/:id/status  (admin)  { status }
exports.updateOrderStatus = async (req, res, next) => {
  try {
    const { status } = req.body;
    const validStatuses = ['Placed', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered', 'Cancelled'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ message: 'Invalid order status.' });
    }
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'Order not found.' });
    order.orderStatus = status;
    order.statusHistory.push({ status });
    await order.save();
    res.json(order);
  } catch (error) {
    next(error);
  }
};
