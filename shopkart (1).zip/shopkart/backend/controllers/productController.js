const Product = require('../models/Product');

function slugify(text) {
  return text.toString().toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '') + '-' + Date.now().toString(36);
}

// GET /api/products
// Supports: search, category, brand, minPrice, maxPrice, minRating, minDiscount,
// sort (relevance | price_asc | price_desc | rating), page, limit, featured, deal
exports.getProducts = async (req, res, next) => {
  try {
    const {
      search, category, brand, minPrice, maxPrice, minRating, minDiscount,
      sort = 'relevance', page = 1, limit = 12, featured, deal,
    } = req.query;

    const filter = {};
    if (search) filter.$text = { $search: search };
    if (category) filter.category = category;
    if (brand) filter.brand = { $in: brand.split(',') };
    if (minPrice || maxPrice) {
      filter.price = {};
      if (minPrice) filter.price.$gte = Number(minPrice);
      if (maxPrice) filter.price.$lte = Number(maxPrice);
    }
    if (minRating) filter.rating = { $gte: Number(minRating) };
    if (featured) filter.isFeatured = true;
    if (deal) filter.isDeal = true;

    let query = Product.find(filter).populate('category', 'name slug');

    // Discount is a virtual, so filter it in JS after fetching if requested.
    let products = await query;
    if (minDiscount) {
      products = products.filter((p) => p.discountPercent >= Number(minDiscount));
    }

    // Sorting
    if (sort === 'price_asc') products.sort((a, b) => a.price - b.price);
    else if (sort === 'price_desc') products.sort((a, b) => b.price - a.price);
    else if (sort === 'rating') products.sort((a, b) => b.rating - a.rating);
    // 'relevance' keeps default order (or text-search score order)

    const total = products.length;
    const pageNum = Math.max(1, Number(page));
    const limitNum = Math.max(1, Number(limit));
    const start = (pageNum - 1) * limitNum;
    const paginated = products.slice(start, start + limitNum);

    // Collect distinct brands for the current filtered category (used by filter sidebar).
    const brands = [...new Set(products.map((p) => p.brand))];

    res.json({
      products: paginated,
      total,
      page: pageNum,
      pages: Math.ceil(total / limitNum),
      brands,
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/products/:id
exports.getProductById = async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id).populate('category', 'name slug');
    if (!product) return res.status(404).json({ message: 'Product not found.' });
    res.json(product);
  } catch (error) {
    next(error);
  }
};

// POST /api/products (admin)
exports.createProduct = async (req, res, next) => {
  try {
    const body = req.body;
    if (!body.name || !body.price || !body.mrp || !body.category) {
      return res.status(400).json({ message: 'Name, price, mrp and category are required.' });
    }
    const product = await Product.create({
      ...body,
      slug: slugify(body.name),
      images: body.images && body.images.length ? body.images : ['/images/placeholder.svg'],
    });
    res.status(201).json(product);
  } catch (error) {
    next(error);
  }
};

// PUT /api/products/:id (admin)
exports.updateProduct = async (req, res, next) => {
  try {
    const product = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!product) return res.status(404).json({ message: 'Product not found.' });
    res.json(product);
  } catch (error) {
    next(error);
  }
};

// DELETE /api/products/:id (admin)
exports.deleteProduct = async (req, res, next) => {
  try {
    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) return res.status(404).json({ message: 'Product not found.' });
    res.json({ message: 'Product deleted.' });
  } catch (error) {
    next(error);
  }
};
