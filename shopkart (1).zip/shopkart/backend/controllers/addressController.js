const Address = require('../models/Address');

// GET /api/addresses
exports.getAddresses = async (req, res, next) => {
  try {
    const addresses = await Address.find({ user: req.user._id }).sort('-isDefault -createdAt');
    res.json(addresses);
  } catch (error) {
    next(error);
  }
};

// POST /api/addresses
exports.addAddress = async (req, res, next) => {
  try {
    const { fullName, phone, pincode, addressLine, city, state, type, isDefault } = req.body;
    if (!fullName || !phone || !pincode || !addressLine || !city || !state) {
      return res.status(400).json({ message: 'All address fields are required.' });
    }
    if (!/^\d{6}$/.test(pincode)) {
      return res.status(400).json({ message: 'Pincode must be a 6-digit number.' });
    }
    if (isDefault) {
      await Address.updateMany({ user: req.user._id }, { isDefault: false });
    }
    const address = await Address.create({
      user: req.user._id, fullName, phone, pincode, addressLine, city, state, type, isDefault,
    });
    res.status(201).json(address);
  } catch (error) {
    next(error);
  }
};

// PUT /api/addresses/:id
exports.updateAddress = async (req, res, next) => {
  try {
    if (req.body.isDefault) {
      await Address.updateMany({ user: req.user._id }, { isDefault: false });
    }
    const address = await Address.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id }, req.body, { new: true }
    );
    if (!address) return res.status(404).json({ message: 'Address not found.' });
    res.json(address);
  } catch (error) {
    next(error);
  }
};

// DELETE /api/addresses/:id
exports.deleteAddress = async (req, res, next) => {
  try {
    const address = await Address.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!address) return res.status(404).json({ message: 'Address not found.' });
    res.json({ message: 'Address deleted.' });
  } catch (error) {
    next(error);
  }
};
