const Category = require('../models/Category');
const Product = require('../models/Product');

function slugify(text) {
  return text.toString().toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
}

// GET /api/categories
exports.getCategories = async (req, res, next) => {
  try {
    const categories = await Category.find().sort('name');
    res.json(categories);
  } catch (error) {
    next(error);
  }
};

// POST /api/categories (admin)
exports.createCategory = async (req, res, next) => {
  try {
    const { name, icon, image } = req.body;
    if (!name) return res.status(400).json({ message: 'Category name is required.' });
    const slug = slugify(name);
    const exists = await Category.findOne({ slug });
    if (exists) return res.status(409).json({ message: 'A category with this name already exists.' });
    const category = await Category.create({ name, slug, icon, image });
    res.status(201).json(category);
  } catch (error) {
    next(error);
  }
};

// PUT /api/categories/:id (admin)
exports.updateCategory = async (req, res, next) => {
  try {
    const { name, icon, image } = req.body;
    const update = { icon, image };
    if (name) update.name = name, update.slug = slugify(name);
    const category = await Category.findByIdAndUpdate(req.params.id, update, { new: true });
    if (!category) return res.status(404).json({ message: 'Category not found.' });
    res.json(category);
  } catch (error) {
    next(error);
  }
};

// DELETE /api/categories/:id (admin)
exports.deleteCategory = async (req, res, next) => {
  try {
    const inUse = await Product.countDocuments({ category: req.params.id });
    if (inUse > 0) {
      return res.status(400).json({ message: `Cannot delete: ${inUse} product(s) use this category.` });
    }
    const category = await Category.findByIdAndDelete(req.params.id);
    if (!category) return res.status(404).json({ message: 'Category not found.' });
    res.json({ message: 'Category deleted.' });
  } catch (error) {
    next(error);
  }
};
