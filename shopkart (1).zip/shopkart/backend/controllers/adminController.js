const Order = require('../models/Order');
const Product = require('../models/Product');
const User = require('../models/User');

// GET /api/admin/stats
exports.getStats = async (req, res, next) => {
  try {
    const [totalOrders, totalProducts, totalUsers, orders] = await Promise.all([
      Order.countDocuments(),
      Product.countDocuments(),
      User.countDocuments({ role: 'user' }),
      Order.find().sort('-createdAt').limit(500),
    ]);

    const totalRevenue = orders.reduce((sum, o) => sum + o.totalPrice, 0);

    const lowStock = await Product.find({ stock: { $lte: 5 } }).select('name stock').limit(10);

    // Revenue for the last 7 days (by day).
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      d.setHours(0, 0, 0, 0);
      days.push(d);
    }
    const revenueByDay = days.map((day) => {
      const next = new Date(day);
      next.setDate(next.getDate() + 1);
      const total = orders
        .filter((o) => o.createdAt >= day && o.createdAt < next)
        .reduce((sum, o) => sum + o.totalPrice, 0);
      return { date: day.toLocaleDateString('en-IN', { weekday: 'short' }), total };
    });

    const recentOrders = await Order.find().populate('user', 'name').sort('-createdAt').limit(5);

    res.json({
      totalOrders, totalProducts, totalUsers, totalRevenue,
      lowStock, revenueByDay, recentOrders,
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/admin/users
exports.getUsers = async (req, res, next) => {
  try {
    const users = await User.find({ role: 'user' }).select('-password').sort('-createdAt');
    res.json(users);
  } catch (error) {
    next(error);
  }
};

// DELETE /api/admin/users/:id
exports.deleteUser = async (req, res, next) => {
  try {
    const user = await User.findOneAndDelete({ _id: req.params.id, role: 'user' });
    if (!user) return res.status(404).json({ message: 'User not found.' });
    res.json({ message: 'User deleted.' });
  } catch (error) {
    next(error);
  }
};
