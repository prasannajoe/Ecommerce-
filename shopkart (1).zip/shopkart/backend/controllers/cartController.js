const Cart = require('../models/Cart');
const Product = require('../models/Product');

async function getOrCreateCart(userId) {
  let cart = await Cart.findOne({ user: userId });
  if (!cart) cart = await Cart.create({ user: userId, items: [] });
  return cart;
}

// GET /api/cart
exports.getCart = async (req, res, next) => {
  try {
    const cart = await getOrCreateCart(req.user._id);
    const populated = await cart.populate('items.product');
    res.json(populated);
  } catch (error) {
    next(error);
  }
};

// POST /api/cart  { productId, quantity }
exports.addToCart = async (req, res, next) => {
  try {
    const { productId, quantity = 1 } = req.body;
    const product = await Product.findById(productId);
    if (!product) return res.status(404).json({ message: 'Product not found.' });
    if (product.stock < 1) return res.status(400).json({ message: 'This product is out of stock.' });

    const cart = await getOrCreateCart(req.user._id);
    const existing = cart.items.find((i) => i.product.toString() === productId && !i.savedForLater);
    if (existing) existing.quantity += Number(quantity);
    else cart.items.push({ product: productId, quantity: Number(quantity) });
    await cart.save();
    const populated = await cart.populate('items.product');
    res.status(201).json(populated);
  } catch (error) {
    next(error);
  }
};

// PUT /api/cart/:productId  { quantity }
exports.updateCartItem = async (req, res, next) => {
  try {
    const { quantity } = req.body;
    const cart = await getOrCreateCart(req.user._id);
    const item = cart.items.find((i) => i.product.toString() === req.params.productId);
    if (!item) return res.status(404).json({ message: 'Item not in cart.' });
    if (quantity < 1) return res.status(400).json({ message: 'Quantity must be at least 1.' });
    item.quantity = quantity;
    await cart.save();
    const populated = await cart.populate('items.product');
    res.json(populated);
  } catch (error) {
    next(error);
  }
};

// PUT /api/cart/:productId/save-for-later
exports.toggleSaveForLater = async (req, res, next) => {
  try {
    const cart = await getOrCreateCart(req.user._id);
    const item = cart.items.find((i) => i.product.toString() === req.params.productId);
    if (!item) return res.status(404).json({ message: 'Item not in cart.' });
    item.savedForLater = !item.savedForLater;
    await cart.save();
    const populated = await cart.populate('items.product');
    res.json(populated);
  } catch (error) {
    next(error);
  }
};

// DELETE /api/cart/:productId
exports.removeFromCart = async (req, res, next) => {
  try {
    const cart = await getOrCreateCart(req.user._id);
    cart.items = cart.items.filter((i) => i.product.toString() !== req.params.productId);
    await cart.save();
    const populated = await cart.populate('items.product');
    res.json(populated);
  } catch (error) {
    next(error);
  }
};

// DELETE /api/cart
exports.clearCart = async (req, res, next) => {
  try {
    const cart = await getOrCreateCart(req.user._id);
    cart.items = [];
    await cart.save();
    res.json(cart);
  } catch (error) {
    next(error);
  }
};
