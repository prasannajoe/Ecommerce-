const Review = require('../models/Review');
const Product = require('../models/Product');

async function recalculateProductRating(productId) {
  const reviews = await Review.find({ product: productId });
  const numReviews = reviews.length;
  const rating = numReviews ? reviews.reduce((sum, r) => sum + r.rating, 0) / numReviews : 0;
  await Product.findByIdAndUpdate(productId, { rating: rating.toFixed(1), numReviews });
}

// GET /api/reviews/:productId
exports.getReviews = async (req, res, next) => {
  try {
    const reviews = await Review.find({ product: req.params.productId }).sort('-createdAt');
    res.json(reviews);
  } catch (error) {
    next(error);
  }
};

// POST /api/reviews/:productId   { rating, comment }
exports.addReview = async (req, res, next) => {
  try {
    const { rating, comment } = req.body;
    if (!rating || !comment) {
      return res.status(400).json({ message: 'Rating and comment are required.' });
    }
    const existing = await Review.findOne({ product: req.params.productId, user: req.user._id });
    if (existing) {
      return res.status(409).json({ message: 'You have already reviewed this product.' });
    }
    const review = await Review.create({
      product: req.params.productId, user: req.user._id,
      userName: req.user.name, rating, comment,
    });
    await recalculateProductRating(req.params.productId);
    res.status(201).json(review);
  } catch (error) {
    next(error);
  }
};
