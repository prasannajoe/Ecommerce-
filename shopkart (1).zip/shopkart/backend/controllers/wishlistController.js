const Wishlist = require('../models/Wishlist');

async function getOrCreateWishlist(userId) {
  let wishlist = await Wishlist.findOne({ user: userId });
  if (!wishlist) wishlist = await Wishlist.create({ user: userId, products: [] });
  return wishlist;
}

// GET /api/wishlist
exports.getWishlist = async (req, res, next) => {
  try {
    const wishlist = await getOrCreateWishlist(req.user._id);
    const populated = await wishlist.populate('products');
    res.json(populated);
  } catch (error) {
    next(error);
  }
};

// POST /api/wishlist/:productId  (toggles on/off)
exports.toggleWishlist = async (req, res, next) => {
  try {
    const wishlist = await getOrCreateWishlist(req.user._id);
    const { productId } = req.params;
    const exists = wishlist.products.some((p) => p.toString() === productId);
    if (exists) {
      wishlist.products = wishlist.products.filter((p) => p.toString() !== productId);
    } else {
      wishlist.products.push(productId);
    }
    await wishlist.save();
    const populated = await wishlist.populate('products');
    res.json(populated);
  } catch (error) {
    next(error);
  }
};
