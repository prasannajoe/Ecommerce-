// Handles the connection to our MongoDB database using Mongoose.
const mongoose = require('mongoose');

async function connectDB() {
  try {
    const uri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/shopkart';
    await mongoose.connect(uri);
    console.log('MongoDB connected:', uri);
  } catch (error) {
    console.error('MongoDB connection failed:', error.message);
    // Stop the app if we cannot reach the database.
    process.exit(1);
  }
}

module.exports = connectDB;
