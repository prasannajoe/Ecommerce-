// A single line item inside an order. Kept as its own model (referenced by Order)
// so the database structure matches a normal relational-style e-commerce schema,
// even though Mongoose also lets us embed items directly.
const mongoose = require('mongoose');

const orderItemSchema = new mongoose.Schema(
  {
    order: { type: mongoose.Schema.Types.ObjectId, ref: 'Order', required: true },
    product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    name: { type: String, required: true }, // snapshot of product name at order time
    image: { type: String },
    price: { type: Number, required: true }, // snapshot of price at order time
    quantity: { type: Number, required: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('OrderItem', orderItemSchema);
