// A customer order. Line items are embedded for easy reads, and mirrored in the
// OrderItem collection for reporting/joins.
const mongoose = require('mongoose');

const embeddedItemSchema = new mongoose.Schema(
  {
    product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    name: { type: String, required: true },
    image: { type: String },
    price: { type: Number, required: true },
    quantity: { type: Number, required: true },
  },
  { _id: false }
);

const shippingAddressSchema = new mongoose.Schema(
  {
    fullName: String,
    phone: String,
    pincode: String,
    addressLine: String,
    city: String,
    state: String,
  },
  { _id: false }
);

const orderSchema = new mongoose.Schema(
  {
    orderNumber: { type: String, required: true, unique: true }, // human-friendly order ID
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    items: [embeddedItemSchema],
    shippingAddress: shippingAddressSchema,
    paymentMethod: { type: String, enum: ['UPI', 'Card', 'NetBanking', 'COD'], required: true },
    paymentStatus: { type: String, enum: ['Pending', 'Paid', 'Failed'], default: 'Pending' },
    itemsPrice: { type: Number, required: true },
    discount: { type: Number, required: true, default: 0 },
    deliveryCharge: { type: Number, required: true, default: 0 },
    totalPrice: { type: Number, required: true },
    orderStatus: {
      type: String,
      enum: ['Placed', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered', 'Cancelled'],
      default: 'Placed',
    },
    statusHistory: [
      {
        status: String,
        date: { type: Date, default: Date.now },
      },
    ],
  },
  { timestamps: true }
);

module.exports = mongoose.model('Order', orderSchema);
