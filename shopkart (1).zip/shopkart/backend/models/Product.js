// Products available in the store.
const mongoose = require('mongoose');

const productSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    slug: { type: String, required: true, unique: true, lowercase: true },
    description: { type: String, required: true },
    category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true },
    brand: { type: String, required: true, trim: true },
    price: { type: Number, required: true }, // current selling price
    mrp: { type: Number, required: true }, // original "maximum retail price" before discount
    images: [{ type: String }], // image URLs (uploaded files or seed placeholders)
    stock: { type: Number, required: true, default: 0 },
    specifications: { type: Map, of: String, default: {} }, // e.g. { "RAM": "8GB" }
    rating: { type: Number, default: 0 },
    numReviews: { type: Number, default: 0 },
    isFeatured: { type: Boolean, default: false }, // used for "Trending" section
    isDeal: { type: Boolean, default: false }, // used for "Best Deals" section
  },
  { timestamps: true }
);

// Virtual field: discount percentage, calculated automatically from price and mrp.
productSchema.virtual('discountPercent').get(function () {
  if (!this.mrp || this.mrp <= this.price) return 0;
  return Math.round(((this.mrp - this.price) / this.mrp) * 100);
});

productSchema.set('toJSON', { virtuals: true });
productSchema.set('toObject', { virtuals: true });

// Text index so /api/products?search=... works.
productSchema.index({ name: 'text', description: 'text', brand: 'text' });

module.exports = mongoose.model('Product', productSchema);
