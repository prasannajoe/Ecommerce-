// Central place that turns thrown errors into consistent JSON responses.
function errorHandler(err, req, res, next) {
  console.error(err);
  const statusCode = err.statusCode || (res.statusCode !== 200 ? res.statusCode : 500);
  res.status(statusCode).json({
    message: err.message || 'Something went wrong on the server.',
  });
}

module.exports = errorHandler;
