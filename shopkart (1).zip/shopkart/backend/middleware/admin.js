// Must run after `protect`. Blocks the request unless the logged-in user is an admin.
function adminOnly(req, res, next) {
  if (req.user && req.user.role === 'admin') {
    return next();
  }
  return res.status(403).json({ message: 'Admin access required.' });
}

module.exports = adminOnly;
