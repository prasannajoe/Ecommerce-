const express = require('express');
const router = express.Router();
const protect = require('../middleware/auth');
const {
  getCart, addToCart, updateCartItem, toggleSaveForLater, removeFromCart, clearCart,
} = require('../controllers/cartController');

router.use(protect); // every cart route requires login
router.get('/', getCart);
router.post('/', addToCart);
router.put('/:productId', updateCartItem);
router.put('/:productId/save-for-later', toggleSaveForLater);
router.delete('/:productId', removeFromCart);
router.delete('/', clearCart);

module.exports = router;
