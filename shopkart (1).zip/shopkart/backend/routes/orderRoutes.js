const express = require('express');
const router = express.Router();
const protect = require('../middleware/auth');
const adminOnly = require('../middleware/admin');
const {
  createOrder, getMyOrders, getOrderById, getAllOrders, updateOrderStatus,
} = require('../controllers/orderController');

router.use(protect);
router.get('/admin/all', adminOnly, getAllOrders);
router.put('/:id/status', adminOnly, updateOrderStatus);
router.post('/', createOrder);
router.get('/', getMyOrders);
router.get('/:id', getOrderById);

module.exports = router;
